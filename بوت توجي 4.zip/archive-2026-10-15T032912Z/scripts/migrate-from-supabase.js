#!/usr/bin/env node
/**
 * نقل لمرة واحدة: Supabase → MongoDB
 *   • جدول bot_backup (الصف "main")  →  مجموعة bot_state (بنفس صيغة mongoSync)
 *   • جدول titles                    →  مجموعة titles
 *
 * الاستخدام (من Console الاستضافة أو جهازك):
 *   SUPABASE_URL=... SUPABASE_KEY=... MONGODB_URI=... npm run migrate-supabase
 * (أو ضعها في .env). لا يمسح أي شي من Supabase، ولا يستبدل بيانات موجودة بنفس
 * القسم/اللقب في MongoDB إلا لو مرّرت --force.
 */
require("dotenv").config();
const { MongoClient } = require("mongodb");

const SB_URL = (process.env.SUPABASE_URL || "").replace(/\/+$/, "");
const SB_KEY = process.env.SUPABASE_KEY || "";
const MONGO_URI = process.env.MONGODB_URI || "";
const FORCE = process.argv.includes("--force");
const CHUNK = 3_000_000;

if (!SB_URL || !SB_KEY || !MONGO_URI) {
  console.error("❌ لازم SUPABASE_URL و SUPABASE_KEY و MONGODB_URI كلها مضبوطة.");
  process.exit(1);
}

function dbNameFromUri(uri) {
  if (process.env.MONGODB_DB) return process.env.MONGODB_DB;
  const m = uri.match(/^mongodb(?:\+srv)?:\/\/[^/]+\/([^?]+)/i);
  return m && m[1] ? decodeURIComponent(m[1]) : "boody_bot";
}

async function sb(pathAndQuery) {
  const res = await fetch(`${SB_URL}/rest/v1/${pathAndQuery}`, {
    headers: { apikey: SB_KEY, Authorization: `Bearer ${SB_KEY}` },
  });
  if (!res.ok) throw new Error(`Supabase ${res.status}: ${await res.text()}`);
  return res.json();
}

(async () => {
  const client = new MongoClient(MONGO_URI, { serverSelectionTimeoutMS: 15000 });
  await client.connect();
  const db = client.db(dbNameFromUri(MONGO_URI));

  // 1) بيانات البوت
  const rows = await sb("bot_backup?id=eq.main&select=data");
  const state = rows[0] && rows[0].data;
  if (state && typeof state === "object") {
    const state$ = db.collection("bot_state");
    const existing = await state$.countDocuments();
    if (existing > 0 && !FORCE) {
      console.log(`⏭️  bot_state فيه بيانات أصلًا (${existing} جزء) — تخطيت. استخدم --force للاستبدال.`);
    } else {
      if (FORCE) await state$.deleteMany({});
      let n = 0;
      for (const key of Object.keys(state)) {
        const json = JSON.stringify(state[key]) ?? "null";
        const parts = [];
        for (let i = 0; i < json.length || i === 0; i += CHUNK) parts.push(json.slice(i, i + CHUNK));
        for (let i = 0; i < parts.length; i++) {
          await state$.replaceOne(
            { _id: `${key}::${i}` },
            { key, part: i, parts: parts.length, json: parts[i], updatedAt: new Date() },
            { upsert: true }
          );
        }
        n++;
      }
      console.log(`✅ نُقلت ${n} أقسام من بيانات البوت.`);
    }
  } else {
    console.log("ℹ️  ما لقيت نسخة bot_backup في Supabase.");
  }

  // 2) الألقاب
  let titles = [];
  try {
    titles = await sb("titles?select=user_id,title,updated_at");
  } catch (e) {
    console.log("ℹ️  تعذّر قراءة جدول titles:", e.message);
  }
  if (titles.length) {
    const t$ = db.collection("titles");
    await t$.createIndex({ userId: 1 }, { unique: true });
    await t$.createIndex({ title: 1 }, { unique: true });
    let ok = 0, skipped = 0;
    for (const r of titles) {
      try {
        const doc = { userId: r.user_id, title: r.title, updatedAt: r.updated_at ? new Date(r.updated_at) : new Date() };
        if (FORCE) await t$.replaceOne({ userId: r.user_id }, doc, { upsert: true });
        else await t$.insertOne(doc);
        ok++;
      } catch (e) {
        if (e && e.code === 11000) skipped++;
        else throw e;
      }
    }
    console.log(`✅ الألقاب: نُقل ${ok}، موجود مسبقًا/مكرر ${skipped}.`);
  } else {
    console.log("ℹ️  لا ألقاب للنقل.");
  }

  await client.close();
  console.log("🎉 انتهى النقل. تقدر تحذف SUPABASE_URL/SUPABASE_KEY من الإعدادات.");
})().catch((e) => {
  console.error("❌ فشل النقل:", e.message || e);
  process.exit(1);
});
