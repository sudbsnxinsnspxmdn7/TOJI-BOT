import { Command } from "../../handlers/types";
import { commandRegistry } from "../../handlers/commandRegistry";
import { buildCommandDirectory } from "../../utils/commandDirectory";
import { CONFIG } from "../../config/config";

const command: Command = {
  name: "اوامر_البوتس",
  aliases: ["أوامر_البوتس", "قائمة_الأوامر", "كل_الأوامر"],
  category: "بوت",
  description: "يعرض دليل أوامر البوت كاملًا مع وصف كل أمر، على صفحات",
  permission: "all",
  execute: async (ctx) => {
    const requestedPage = ctx.args[0] ? Number(ctx.args[0]) : 1;
    const directory = buildCommandDirectory(
      commandRegistry.getAll().map((registered) => ({
        ...registered,
        aliases: commandRegistry.getAliases(registered.name),
      })),
      CONFIG.PREFIX,
      requestedPage
    );

    if (!Number.isInteger(requestedPage) || requestedPage < 1) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text: `⚠️ اكتب رقم صفحة صحيحًا. مثال: ${CONFIG.PREFIX}اوامر_البوتس 2`,
        },
        { quoted: ctx.msg }
      );
      return;
    }

    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: directory.text },
      { quoted: ctx.msg }
    );
  },
};

export default command;
