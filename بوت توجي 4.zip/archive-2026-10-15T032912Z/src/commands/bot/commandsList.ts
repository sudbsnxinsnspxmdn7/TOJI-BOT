import { Command } from "../../handlers/types";
import { commandRegistry } from "../../handlers/commandRegistry";
import { CONFIG } from "../../config/config";
import { sendCarousel, CarouselCard } from "../../utils/carousel";
import { getSectionImageBuffer } from "../../utils/media";
import { logger } from "../../utils/logger";

/**
 * .الاوامر — يعرض كل أوامر البوت المسجّلة بدون أي استثناء (حتى أوامر المطور
 * والمشرفين)، مقسّمة حسب القسم، ككاروسيل تتحرك يمين/يسار. نقرأها من
 * commandRegistry الحي، فأي أمر جديد يظهر هنا تلقائيًا.
 * (الدليل المفصّل بالوصف والبدائل يبقى بـ.اوامر_البوتس)
 */
const LABELS: Record<string, string> = {
  "بوت": "🤖 البوت", "مشرفين": "🛡️ المشرفون", "حماية": "🔐 الحماية", "ترفيه": "🎉 الترفيه",
  "ادوات": "🧰 الأدوات", "اعدادات": "⚙️ الإعدادات", "السنة": "🌙 السنة", "المطور": "👑 المطور",
  "IA": "✨ الذكاء الاصطناعي", "تحليل": "🔎 التحليل", "العاب2D": "🕹️ ألعاب 2D", "تنصيب": "📲 التنصيب",
  "الراوي": "📖 الراوي", "اوامر_جانبيه": "➕ جانبية", "تعديل_الصور": "🖼️ تعديل الصور",
};
const MAX_CHARS = 850;
const MAX_CARDS = 10;

const command: Command = {
  name: "الاوامر",
  aliases: ["كل_اوامر_البوت", "اسم_الاوامر"],
  category: "بوت",
  description: "يعرض كل أوامر البوت بدون استثناء (كاروسيل)",
  permission: "all",
  execute: async (ctx) => {
    const p = CONFIG.PREFIX;
    const all = commandRegistry.getAll();
    const byCat = new Map<string, string[]>();
    for (const c of all) {
      const key = c.category || "أخرى";
      if (!byCat.has(key)) byCat.set(key, []);
      byCat.get(key)!.push(`${p}${c.name}`);
    }

    const pieces: string[] = [];
    for (const [cat, names] of [...byCat.entries()].sort((a, b) => a[0].localeCompare(b[0], "ar"))) {
      names.sort((a, b) => a.localeCompare(b, "ar"));
      const title = `✦ ${LABELS[cat] || cat} (${names.length})`;
      let cur = title;
      for (const n of names) {
        if ((cur + "\n" + n).length > MAX_CHARS) {
          pieces.push(cur);
          cur = `${title} — تابع`;
        }
        cur += `\n${n}`;
      }
      pieces.push(cur);
    }

    const image = getSectionImageBuffer("main") || getSectionImageBuffer("bot");
    if (!image) {
      // لا توجد صورة بطاقة — نرسل النص كاملًا (مقسّم) بدل ما نخفي أي أمر
      for (let i = 0; i < pieces.length; i += 4) {
        await ctx.sock.sendMessage(ctx.chatId, { text: pieces.slice(i, i + 4).join("\n\n") });
      }
      return;
    }

    const short = CONFIG.BOT_NAME.replace(/\\n|\n/g, " ");
    const batches = Math.ceil(pieces.length / MAX_CARDS);
    for (let b = 0; b < batches; b++) {
      const slice = pieces.slice(b * MAX_CARDS, (b + 1) * MAX_CARDS);
      const cards: CarouselCard[] = slice.map((body, i) => ({
        image,
        body: `${body}\n\n(${b * MAX_CARDS + i + 1}/${pieces.length})`,
        footer: short,
      }));
      try {
        await sendCarousel(ctx.sock, ctx.chatId, {
          text: `📚 كل أوامر البوت (${all.length} أمر) — ${b + 1}/${batches}\n➜ اسحب لرؤية باقي الأقسام`,
          footer: short,
          cards,
          quoted: b === 0 ? ctx.msg : undefined,
        });
      } catch (err) {
        logger.error("فشل إرسال قائمة كل الأوامر:", err);
      }
    }
  },
};

export default command;
