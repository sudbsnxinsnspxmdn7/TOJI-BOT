import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { formatDateTime, jidToMention } from "../../utils/helpers";
import { getMenuVideoBuffer, getSectionImageBuffer } from "../../utils/media";
import { sendButtonMessage, buildSingleSelectButton, sectionButton } from "../../utils/interactive";
import { mainMenuText } from "../../utils/menuTemplates";
import { commandRegistry } from "../../handlers/commandRegistry";
import { MENU_SECTIONS } from "../../utils/menuSections";
import { sendCarousel } from "../../utils/carousel";
import { getPtvBuffer } from "../../events/groupJoinPtv";
import { notifyOwnerOfError } from "../../utils/helpers";
import { sideMenuText } from "../../utils/botMessages";
import { logger } from "../../utils/logger";

const command: Command = {
  name: "menu",
  // 🔧 ملاحظة: أزلنا "بوت" من هنا لأنه صار أمرًا مستقلًا بصورة وقسم خاص به
  // (src/commands/bot/botInfo.ts) بدل ما يكون مجرد اسم بديل لهذي القائمة.
  aliases: ["اوامر", "help", "قائمة"],
  category: "بوت",
  description: "عرض القائمة الرئيسية للبوت",
  permission: "all",
  execute: async (ctx) => {
    // ملاحظة: تفاعل التأكيد بقى مركزيًا بـ messageHandler لكل الأوامر،
    // فما نحتاج نرسله يدويًا هنا بعد الحين.
    const { date, time } = formatDateTime();
    const groupName = ctx.metadata?.subject || "خاص";
    const userMention = jidToMention(ctx.senderJid);
    // استجابة فعلية: الفرق بين وقت استلام الرسالة (timestamp من واتساب) والآن
    const sentAt = Number(ctx.msg.messageTimestamp || 0) * 1000;
    const ping = sentAt ? Math.max(0, Date.now() - sentAt) : 0;

    // 🔧 (طلب صريح: استمارة منيو جديدة) — نفس المتغيرات السابقة
    // (اسم الكروب/المستخدم/التاريخ/الوقت)، بإضافة البينغ اللي كان محسوب
    // من قبل بس ما كان يُعرض بالقالب القديم.
    const menuText = mainMenuText({
      user: userMention,
      time,
      date,
      count: commandRegistry.count(),
      group: groupName,
      prefix: CONFIG.PREFIX,
    });

    // رسالة واحدة فقط: الفيديو/الصورة + النص + الأزرار الحقيقية مرفقين معًا
    // (بدل ما ترسل بشكل منفصل بطريقة غير احترافية). لو تعذّرت الأزرار
    // لأي سبب (بعض الأجهزة لا تدعمها) يرجع تلقائيًا لنفس الصورة/الفيديو
    // مع النص بدون أزرار — يبقى رسالة وحدة برضه، وبدون كسر أي شيء.

    // 🆕 (طلب صريح) أول ما يكتب .اوامر: الفيديو الدائري (محضّر مسبقًا بالذاكرة
    // فيرسل فورًا بدون انتظار)، ثم القائمة القديمة نفسها (بدون تغيير) كما كانت.
    try {
      const ptv = await getPtvBuffer();
      if (ptv) await ctx.sock.sendMessage(ctx.chatId, { video: ptv, ptv: true } as any);
    } catch (err) {
      logger.warn("⚠️ تعذر إرسال الفيديو الدائري مع القائمة:", err);
    }

    // 🆕 (طلب صريح) بعد الفيديو الدائري: بطاقة "الأوامر" وبجنبها بطاقة "الأوامر
    // الجانبية" (يمين/يسار) — كل بطاقة بنفس شكل رسالتها الأصلية (فيديو/صورة المنيو +
    // نفس النص + نفس الأزرار). لو فشل الكاروسيل نرجع للقائمة القديمة بالأسفل.
    const cardVideo = getMenuVideoBuffer();
    const cardImage = getSectionImageBuffer("main") || getSectionImageBuffer("bot") || undefined;
    if (cardVideo || cardImage) {
      try {
        const short = CONFIG.BOT_NAME.replace(/\\n|\n/g, " ");
        const installBtn = CONFIG.SUPPORT_GROUP_LINK
          ? [{ type: "url" as const, label: "🔱الــتــنــصــيــب🔱", value: CONFIG.SUPPORT_GROUP_LINK }]
          : [];
        const sideText = sideMenuText(groupName);
        await sendCarousel(ctx.sock, ctx.chatId, {
          text: "\u200e", // (طلب صريح) حذف نص "اسحب لرؤية الأوامر الجانبية" — محرف خفي حتى يبقى body موجود
          footer: short,
          quoted: ctx.msg,
          mentions: [ctx.senderJid],
          onFail: "throw",
          cards: [
            {
              video: cardVideo || undefined,
              gif: true,
              image: cardImage,
              footer: short,
              body: menuText,
              buttons: [
                process.env.MENU_SELECT_IN_CARD === "0"
                  ? { type: "reply" as const, label: "📂 الأقسام", value: sectionButton("الاقسام", "📂 الأقسام").id }
                  : // زر الأقسام المنسدل الطبيعي (نفس شكل القائمة القديمة) داخل البطاقة
                    { type: "raw" as const, label: "📂 الأقسام", raw: buildSingleSelectButton("📂 الأقسام", "أقسام البوت", MENU_SECTIONS) },
                { type: "reply", label: "💡 اقتراح أمر", value: sectionButton("اقتراح", "💡 اقتراح أمر").id },
                ...installBtn,
              ],
            },
            {
              video: cardVideo || undefined,
              gif: true,
              image: cardImage,
              footer: short,
              body: sideText,
              buttons: [
                { type: "reply", label: "📜 عرض الأوامر", value: sectionButton("اوامر_جانبيه", "📜 عرض الأوامر").id },
                ...(CONFIG.SUPPORT_GROUP_LINK
                  ? [{ type: "url" as const, label: "👨‍💻 المطورين", value: CONFIG.SUPPORT_GROUP_LINK }]
                  : []),
                ...installBtn,
              ],
            },
          ],
        });
        return;
      } catch (err) {
        logger.warn("⚠️ كاروسيل القائمة الرئيسية فشل — رجوع للقائمة القديمة:", err);
        // السبب الحقيقي يوصل المطور على الخاص (نفس أسلوب باقي الأوامر) عشان نعرف ليش ما ظهر الكاروسيل
        await notifyOwnerOfError(ctx.sock, ".اوامر (كاروسيل)", err instanceof Error ? `${err.message}` : String(err), {
          chatId: ctx.chatId,
          senderJid: ctx.senderJid,
        });
      }
    }

    const videoBuffer = getMenuVideoBuffer();
    const mainImage = videoBuffer ? undefined : getSectionImageBuffer("main");

    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text: menuText,
      mentions: [ctx.senderJid],
      video: videoBuffer || undefined,
      gifPlayback: true,
      image: mainImage || undefined,
      // 🆕 (طلب صريح: زر واحد بدل صف الأقسام الطويل) — كل أقسام البوت الآن
      // داخل زر واحد "📂 الأقسام" يفتح قائمة اختيار من واتساب.
      extraButtons: [
        buildSingleSelectButton("📂 الأقسام", "أقسام البوت", MENU_SECTIONS),
      ],
      quickButtons: [sectionButton("اوامر_جانبيه", "✨ الأوامر الجانبية"), sectionButton("اقتراح", "💡 اقتراح أمر")],
      fallbackNote: `اكتب اسم القسم مباشرة، مثال: ${CONFIG.PREFIX}ترفيه`,
    });
  },
};

export default command;