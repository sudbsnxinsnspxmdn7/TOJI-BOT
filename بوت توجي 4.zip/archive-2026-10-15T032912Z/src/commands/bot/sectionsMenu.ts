import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { sendButtonMessage, buildSingleSelectButton } from "../../utils/interactive";
import { getSectionImageBuffer } from "../../utils/media";
import { MENU_SECTIONS } from "../../utils/menuSections";

/** .الاقسام — يفتح قائمة أقسام البوت (زر بطاقة "الأوامر" بالقائمة الرئيسية يشغّله). */
const command: Command = {
  name: "الاقسام",
  aliases: ["اقسام", "sections"],
  category: "بوت",
  description: "يفتح قائمة أقسام البوت",
  permission: "all",
  execute: async (ctx) => {
    await sendButtonMessage(ctx.sock, ctx.chatId, {
      text: "📂 اختر القسم من الزر:",
      mentions: [ctx.senderJid],
      image: getSectionImageBuffer("main") || undefined,
      extraButtons: [buildSingleSelectButton("📂 الأقسام", "أقسام البوت", MENU_SECTIONS)],
      fallbackNote: `اكتب اسم القسم مباشرة، مثال: ${CONFIG.PREFIX}ترفيه`,
    });
  },
};

export default command;
