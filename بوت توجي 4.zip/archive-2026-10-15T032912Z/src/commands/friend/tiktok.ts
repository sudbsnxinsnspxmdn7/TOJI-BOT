import { Command } from "../../handlers/types";
import { detectPlatform, resolveVideo, searchTikTokVideo, downloadBuffer } from "../../utils/downloader";
import { ytdlpDownload } from "../../utils/ytdlp";
import { notifyOwnerOfError } from "../../utils/helpers";
import { ensureWhatsAppMp4 } from "../../utils/ffmpegMedia";
import { logger } from "../../utils/logger";
import { reply } from "../../utils/friendUtils";

const command: Command = {
  name: "تيك",
  aliases: ["tiktok", "tt"],
  category: "ادوات",
  description: "تحميل فيديوهات تيك توك بدون علامة مائية، أو البحث بكلمة",
  permission: "all",
  execute: async (ctx) => {
    const q = ctx.text.trim();
    if (!q) return reply(ctx, "❗ اكتب رابط تيك توك أو كلمة بحث. مثال: .تيك ون بيس");
    const isLink = /^https?:\/\//i.test(q) && detectPlatform(q) === "tiktok";
    try {
      let buf: Buffer | undefined;
      try {
        const videoUrl = isLink ? (await resolveVideo(q, "tiktok")).videoUrl : (await searchTikTokVideo(q))?.videoUrl;
        if (!videoUrl) return reply(ctx, "❌ ما لقيت فيديو.");
        buf = await downloadBuffer(videoUrl, () => undefined, "tiktok");
      } catch (primaryErr) {
        if (!isLink) throw primaryErr;
        // 🆕 احتياطي yt-dlp لو tikwm/وسطاءه فشلوا
        logger.warn("⚠️ تيك: المسار الأساسي فشل، نجرّب yt-dlp:", primaryErr instanceof Error ? primaryErr.message : primaryErr);
        buf = (await ytdlpDownload(q, "video")).buffer;
      }
      await ctx.sock.sendMessage(ctx.chatId, { video: await ensureWhatsAppMp4(buf).catch(() => buf), caption: "✅ تيك توك - 𝑩𝑶𝑶𝑫𝒀" }, { quoted: ctx.msg });
    } catch (err) {
      logger.error("فشل أمر تيك:", err);
      await notifyOwnerOfError(ctx.sock, ".تيك", String((err as any)?.message || err), { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await reply(ctx, "❌ تعذر تحميل الفيديو حاليًا.");
    }
  },
};
export default command;
