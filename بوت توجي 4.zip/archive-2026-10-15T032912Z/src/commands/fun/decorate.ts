import { Command } from "../../handlers/types";
import { DECORATION_STYLES, applyDecorationStyle } from "../../utils/decorationStyles";

/**
 * 🆕 أمر ".زخرفة" — يحوّل أي نص لشكل مزخرف بنفس روح زر "🔱الــتــنــصــيــب🔱"
 * (تمديد الحروف العربية بالتطويل "ـ")، ولو النص إنجليزي بحت يحوّله لخط
 * "بولد إيطاليك" يونيكود (Mathematical Bold Italic) بنفس طريقة اسم
 * المطور بملف config.ts.
 */

// خريطة تحويل الحروف اللاتينية لخط Mathematical Bold Italic (Unicode)
const BOLD_ITALIC_MAP: Record<string, string> = {
  a: "𝒂", b: "𝒃", c: "𝒄", d: "𝒅", e: "𝒆", f: "𝒇", g: "𝒈", h: "𝒉", i: "𝒊",
  j: "𝒋", k: "𝒌", l: "𝒍", m: "𝒎", n: "𝒏", o: "𝒐", p: "𝒑", q: "𝒒", r: "𝒓",
  s: "𝒔", t: "𝒕", u: "𝒖", v: "𝒗", w: "𝒘", x: "𝒙", y: "𝒚", z: "𝒛",
  A: "𝑨", B: "𝑩", C: "𝑪", D: "𝑫", E: "𝑬", F: "𝑭", G: "𝑮", H: "𝑯", I: "𝑰",
  J: "𝑱", K: "𝑲", L: "𝑳", M: "𝑴", N: "𝑵", O: "𝑶", P: "𝑷", Q: "𝑸", R: "𝑹",
  S: "𝑺", T: "𝑻", U: "𝑼", V: "𝑽", W: "𝑾", X: "𝑿", Y: "𝒀", Z: "𝒁",
};

const ARABIC_RANGE = /[\u0600-\u06FF]/;

const FRAMES: Array<(t: string) => string> = [
  (t) => `⋆༺ ${t} ༻⋆`,
  (t) => `•┈┈•••✦ ${t} ✦•••┈┈•`,
  (t) => `『 ${t} 』`,
  (t) => `✧･ﾟ: *✧･ﾟ:* ${t} *:･ﾟ✧*:･ﾟ✧`,
  (t) => `╭━━━ ${t} ━━━╮`,
  (t) => `꧁༒ ${t} ༒꧂`,
  (t) => `☆彡 ${t} 彡☆`,
  (t) => `﴾ ${t} ﴿`,
  (t) => `【 ${t} 】`,
  (t) => `✿ ${t} ✿`,
  (t) => `ஜ۩۞۩ஜ ${t} ஜ۩۞۩ஜ`,
  (t) => `⸢ ${t} ⸥`,
];

function stretch(input: string, tatweel: string): string {
  return input
    .split("")
    .map((ch) => (ch === " " ? "  " : `${ch}${tatweel}`))
    .join("")
    .replace(new RegExp(`${tatweel}(\\s)`, "g"), "$1")
    .replace(new RegExp(`${tatweel}$`), "");
}

/** يرجع عدة أشكال زخرفة للنص (عربي: تطويل بإطارات متعددة | إنجليزي: كل خطوط يونيكود). */
function decorateAll(input: string): string[] {
  const out: string[] = [];
  if (ARABIC_RANGE.test(input)) {
    const s1 = stretch(input, "ـ");
    const s2 = stretch(input, "ـّ");
    const dotted = input.split("").join("٭");
    FRAMES.forEach((f, i) => out.push(f(i % 3 === 2 ? s2 : i % 3 === 1 ? dotted : s1)));
    out.push(`❝ ${input} ❞`, `${input} ᵕ̈`, `〘${input}〙`);
  }
  // الأحرف/الأرقام اللاتينية لو موجودة (أو كل النص لو إنجليزي)
  if (/[A-Za-z0-9]/.test(input)) {
    DECORATION_STYLES.forEach((_, i) => out.push(`⋆༺ ${applyDecorationStyle(input, i)} ༻⋆`));
    out.push(`⋆༺ ${input.split("").map((ch) => BOLD_ITALIC_MAP[ch] ?? ch).join("")} ༻⋆`);
  }
  if (!out.length) FRAMES.forEach((f) => out.push(f(input)));
  return out;
}

const command: Command = {
  name: "زخرفة",
  aliases: ["زخرف", "decorate"],
  category: "ترفيه",
  description: "يزخرف أي نص بعشرات الأشكال (عربي وإنجليزي). مثال: .زخرفة بودي",
  permission: "all",
  execute: async (ctx) => {
    const input = ctx.text.trim();
    if (!input) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ اكتب نص بعد الأمر. مثال: .زخرفة بودي" },
        { quoted: ctx.msg }
      );
      return;
    }
    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: decorateAll(input).map((v, i) => `${i + 1}- ${v}`).join("\n\n") },
      { quoted: ctx.msg }
    );
  },
};

export default command;
