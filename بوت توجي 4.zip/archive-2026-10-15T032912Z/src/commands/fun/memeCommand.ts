import { Command } from "../../handlers/types";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";
import { searchImages, downloadImageBuffer } from "../../utils/imageSearch";
import { sendErrorMessage } from "../../utils/botMessages";

/**
 * .ميم / .ميمز — ميمز عربية حقيقية من مصادر خارجية (مو رسومات مولّدة من البوت):
 *  1) ريديت: أحدث/أشهر منشورات سبريديتات عربية (reddit.com ثم api.reddit.com ثم meme-api.com).
 *     القائمة قابلة للتعديل من .env بالمتغير MEME_SUBREDDITS (أسماء بدون r/ مفصولة بفاصلة).
 *  2) احتياطي: بحث الصور على الويب بكلمات "ميمز عربي ..." لو ريديت محجوب من استضافتك.
 *
 * ⚠️ صراحة: ما قدرت أجرّب أي مصدر من بيئتي (الشبكة عندي مقيّدة)، وأسماء السبريديتات الافتراضية
 * من معرفتي وقد يكون بعضها غير نشط — الأمر يتخطّى أي مصدر يفشل ويكمل بالتالي.
 */
const DEFAULT_SUBS = ["arabfunny", "ArabicMemes", "arabs", "saudiarabia", "Egypt"];
const UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";
const FALLBACK_QUERIES = ["ميمز عربي مضحك", "ميمز عربية كوميدي", "ميمز سعودي", "ميمز مصري مضحكة", "ميمز عراقي", "ميمز شامي"];
const ARABIC = /[\u0600-\u06FF]/;

interface MemePost {
  url: string;
  title: string;
  source: string;
}

function subs(): string[] {
  const env = (process.env.MEME_SUBREDDITS || "").split(",").map((s) => s.trim()).filter(Boolean);
  return env.length ? env : DEFAULT_SUBS;
}

async function getJson(url: string): Promise<any> {
  const res = await fetch(url, { headers: { "User-Agent": UA, Accept: "application/json" }, signal: AbortSignal.timeout(10_000) });
  if (!res.ok) throw new Error(`HTTP_${res.status}`);
  return res.json();
}

function isImageUrl(u: string): boolean {
  return /^https:\/\/(i\.redd\.it|i\.imgur\.com|preview\.redd\.it)\/.+\.(jpe?g|png|webp)(\?.*)?$/i.test(u);
}

async function fromReddit(sub: string): Promise<MemePost[]> {
  const sort = Math.random() < 0.5 ? "hot" : "top";
  const endpoints = [
    `https://www.reddit.com/r/${sub}/${sort}.json?limit=60&t=month&raw_json=1`,
    `https://api.reddit.com/r/${sub}/${sort}?limit=60&t=month&raw_json=1`,
  ];
  let lastErr: unknown;
  for (const url of endpoints) {
    try {
      const json = await getJson(url);
      const children = json?.data?.children || [];
      return children
        .map((c: any) => c.data)
        .filter((d: any) => d && !d.over_18 && !d.stickied && isImageUrl(d.url_overridden_by_dest || d.url || ""))
        .map((d: any) => ({ url: d.url_overridden_by_dest || d.url, title: String(d.title || ""), source: `r/${sub}` }));
    } catch (err) {
      lastErr = err;
    }
  }
  // وسيط عام لو ريديت يحجب السيرفر
  try {
    const json = await getJson(`https://meme-api.com/gimme/${encodeURIComponent(sub)}/30`);
    return (json?.memes || [])
      .filter((m: any) => m && !m.nsfw && isImageUrl(m.url || ""))
      .map((m: any) => ({ url: m.url, title: String(m.title || ""), source: `r/${sub}` }));
  } catch {
    throw lastErr instanceof Error ? lastErr : new Error("REDDIT_FAILED");
  }
}

function shuffle<T>(arr: T[]): T[] {
  return arr.map((v) => [Math.random(), v] as const).sort((a, b) => a[0] - b[0]).map((x) => x[1]);
}

const command: Command = {
  name: "ميمز",
  aliases: ["ميم", "meme"],
  category: "ترفيه",
  description: "ميم عربي حقيقي من مصادر خارجية (ريديت + بحث الويب)",
  permission: "all",
  execute: async (ctx) => {
    const groupName = ctx.metadata?.subject || "خاص";
    const errors: string[] = [];
    try {
      // 1) ريديت: نجرّب السبريديتات بترتيب عشوائي، ونفضّل المنشورات اللي عنوانها عربي
      for (const sub of shuffle(subs())) {
        try {
          const posts = await fromReddit(sub);
          const arabicFirst = shuffle(posts.filter((p) => ARABIC.test(p.title))).concat(shuffle(posts.filter((p) => !ARABIC.test(p.title))));
          for (const post of arabicFirst.slice(0, 6)) {
            try {
              const image = await downloadImageBuffer(post.url);
              if (!image?.length) continue;
              await ctx.sock.sendMessage(
                ctx.chatId,
                { image, caption: `${post.title ? post.title.slice(0, 200) + "\n" : ""}— ${post.source}` },
                { quoted: ctx.msg }
              );
              return;
            } catch (err) {
              errors.push(`img:${err instanceof Error ? err.message : err}`);
            }
          }
        } catch (err) {
          errors.push(`${sub}:${err instanceof Error ? err.message : err}`);
        }
      }

      // 2) احتياطي: بحث صور ويب بكلمات ميمز عربي
      const queries = shuffle(FALLBACK_QUERIES);
      for (const q of queries.slice(0, 3)) {
        try {
          const urls = shuffle(await searchImages(q, 25));
          for (const url of urls.slice(0, 6)) {
            try {
              const image = await downloadImageBuffer(url);
              if (!image?.length || image.length < 8000) continue;
              await ctx.sock.sendMessage(ctx.chatId, { image, caption: "😂 ميم عربي" }, { quoted: ctx.msg });
              return;
            } catch {
              /* التالي */
            }
          }
        } catch (err) {
          errors.push(`search:${err instanceof Error ? err.message : err}`);
        }
      }
      throw new Error(`ما لقيت ميم من أي مصدر (${errors.slice(0, 3).join(" | ") || "بدون تفاصيل"})`);
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر .ميمز:", err);
      await notifyOwnerOfError(ctx.sock, ".ميمز", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await sendErrorMessage(ctx.sock, ctx.chatId, ctx.senderJid, err, groupName, ctx.msg);
    }
  },
};

export default command;
