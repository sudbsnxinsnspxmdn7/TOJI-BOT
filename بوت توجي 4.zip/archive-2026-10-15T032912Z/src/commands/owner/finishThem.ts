import { downloadMediaMessage } from "@whiskeysockets/baileys";
import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { digitsOnly, buildQuotedMessage } from "../../utils/helpers";
import { getPtvStatus } from "../../events/groupJoinPtv";
import sharp from "sharp";
import fs from "fs";
import path from "path";
import { logger } from "../../utils/logger";
import { findParticipant } from "../../utils/participantMatch";

/**
 * .فنشهم — لصاحب البوت (OWNER_NUMBER/2/3) حصرًا، داخل مجموعة البوت أدمن فيها:
 *   1) يغيّر صورة المجموعة (لو رد على صورة بنفس الأمر)
 *   2) يغيّر اسم المجموعة
 *   3) يبعث فيديو الترحيب الدائري
 *   4) يطرد كل الأعضاء *بطلب واحد* (groupParticipantsUpdate بقائمة كاملة) بدل
 *      طردهم واحدًا واحدًا — نفس طريقة تطبيق واتساب نفسه للإزالة الجماعية، وأقل
 *      عدد طلبات ممكن. لا يطرد البوت نفسه ولا أرقام المطورين.
 *
 * ⚠️ صراحة: ما أقدر أضمن عدم الحظر. واتساب لا يعلن معايير الحظر؛ لكن الطلب
 * الواحد أقل ما يمكن من الطلبات وأقرب لسلوك التطبيق الطبيعي. الأعضاء العاديون
 * يُطردون أولًا بطلب واحد، ثم المشرفون (يُطردون فقط لو البوت منشئ/سوبر أدمن).
 */
const command: Command = {
  name: "فنشهم",
  category: "المطور",
  description: "يغيّر صورة واسم المجموعة ويبعث فيديو الترحيب ويطرد كل الأعضاء بطلب واحد — لصاحب البوت فقط",
  permission: "owner",
  groupOnly: true,
  requireBotAdmin: true,
  execute: async (ctx) => {
    const senderDigits = digitsOnly(ctx.senderJid);
    const primaryOwners = [CONFIG.OWNER_NUMBER, CONFIG.OWNER_NUMBER_2, CONFIG.OWNER_NUMBER_3].filter(Boolean).map(digitsOnly);
    if (!primaryOwners.includes(senderDigits)) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "🚫 هذا الأمر لصاحب البوت فقط." }, { quoted: ctx.msg });
      return;
    }

    const NEW_NAME = "『 𝑩𝑶𝑶𝑫𝒀┆ 🌑 ┆𝒀𝑼𝑴𝑹』";

    try {
      // 1) الصورة: صورة البوت الثابتة (assets/groups/finish.jpg) — ولو رد على صورة بالأمر تُستخدم هي بدلها
      let pictureBuffer: Buffer | undefined;
      if (ctx.quoted?.imageMessage) {
        const source = buildQuotedMessage(ctx.msg) ?? ({ message: ctx.quoted, key: ctx.msg.key } as any);
        pictureBuffer = (await downloadMediaMessage(source, "buffer", {}, {
          logger: logger as any,
          reuploadRequest: ctx.sock.updateMediaMessage,
        })) as Buffer;
      } else {
        const file = path.resolve(process.cwd(), "assets", "groups", "finish.jpg");
        if (fs.existsSync(file)) {
          // نصغّرها لـ640×640 JPEG (أخف وأضمن لرفع صورة المجموعة)
          pictureBuffer = await sharp(file).resize(640, 640, { fit: "cover" }).jpeg({ quality: 90 }).toBuffer();
        }
      }
      if (pictureBuffer) await ctx.sock.updateProfilePicture(ctx.chatId, pictureBuffer);

      // 2) الاسم
      await ctx.sock.groupUpdateSubject(ctx.chatId, NEW_NAME);

      // 3) فيديو الترحيب (نفس مصدر .تست)
      const st = await getPtvStatus();
      if (!("error" in st)) {
        await ctx.sock.sendMessage(ctx.chatId, { video: st.buffer, ptv: true } as any);
      }

      // 4) الطرد الجماعي بطلب واحد
      const metadata = await ctx.sock.groupMetadata(ctx.chatId);
      const botDigits = digitsOnly(ctx.sock.user?.id);
      const protectedDigits = new Set([...primaryOwners, botDigits].filter(Boolean));
      const isProtected = (p: any) =>
        [p.id, p.phoneNumber, p.jid, p.lid].some((v) => v && protectedDigits.has(digitsOnly(String(v))));

      const members = metadata.participants.filter((p: any) => !isProtected(p));
      const regular = members.filter((p: any) => !p.admin).map((p: any) => p.id);
      const admins = members.filter((p: any) => p.admin === "admin").map((p: any) => p.id);

      let removed = 0;
      let failed = 0;
      const removeBatch = async (ids: string[]): Promise<void> => {
        if (!ids.length) return;
        try {
          const res = await ctx.sock.groupParticipantsUpdate(ctx.chatId, ids, "remove");
          const ok = (res || []).filter((r: any) => String(r?.status) === "200").length;
          removed += ok || (res && res.length ? 0 : ids.length);
          failed += (res || []).length - ok;
        } catch (err) {
          failed += ids.length;
          logger.warn("⚠️ فشل طلب الطرد الجماعي:", err);
        }
      };
      await removeBatch(regular); // طلب واحد لكل العاديين
      await removeBatch(admins); // طلب واحد للمشرفين (ينجح فقط لو البوت منشئ المجموعة)

      await ctx.sock.sendMessage(ctx.chatId, {
        text:
          `✅ تم:\n` +
          `🖼️ الصورة\n` +
          `📝 الاسم → ${NEW_NAME}\n` +
          `${"error" in st ? "⏭️ ما فيه فيديو ترحيب محفوظ، تخطّيناه\n" : "🎬 الفيديو\n"}` +
          `🚪 الطرد: ${removed} عضو بطلب واحد${failed ? `\n⚠️ ${failed} ما انطردوا (غالبًا مشرفين والبوت مو منشئ المجموعة)` : ""}`,
      });
    } catch (err) {
      logger.error("فشل أمر .فنشهم:", err);
      await ctx.sock.sendMessage(ctx.chatId, {
        text: `❌ صار خطأ أثناء التنفيذ: ${err instanceof Error ? err.message : String(err)}`,
      });
    }
  },
};

export default command;
