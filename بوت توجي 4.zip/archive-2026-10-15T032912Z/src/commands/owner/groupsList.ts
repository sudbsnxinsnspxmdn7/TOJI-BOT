import { Command } from "../../handlers/types";
import { logger } from "../../utils/logger";
import { getAllSockets } from "../../utils/socketRegistry";

/**
 * .جروبات — للمطور فقط، بالخاص فقط. يجمع كل المجموعات اللي دخلها *كل* مقابس
 * السيرفر (البوت الرئيسي + كل البوتات الفرعية)، بدون تكرار، مع اسم كل مجموعة
 * وعدد أعضائها وأي بوت فيها ورابطها لو أحد البوتات فيها أدمن.
 * طلب الانضمام عبر الرابط: يقبله أي بوت أدمن تلقائيًا لرقم المطور
 * (راجع events/joinRequests.ts).
 *
 * الرابط (groupInviteCode) يتطلب أن يكون البوت أدمن بالمجموعة — نجرّب كل بوت
 * موجود فيها بالترتيب لحد ما ينجح واحد؛ لو ما نجح أي أحد نعرضها بدون رابط.
 */
interface Entry {
  id: string;
  subject: string;
  size: number;
  bots: Array<{ label: string; sock: any }>;
}

const command: Command = {
  name: "جروبات",
  aliases: ["كروبات", "مجموعاتي", "groups", "الجروبات"],
  category: "المطور",
  description: "يعرض كل جروبات السيرفر (كل البوتات الرئيسي والفرعية) + روابطها — للمطور بالخاص",
  permission: "owner",
  groupOnly: false,
  execute: async (ctx) => {
    if (ctx.isGroup) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "⚠️ هذا الأمر يعمل بالخاص فقط (فيه روابط جروبات)." });
      return;
    }

    const all = getAllSockets();
    if (!all.length) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "📭 ما فيه أي بوت متصل حاليًا." });
      return;
    }

    await ctx.sock.sendMessage(ctx.chatId, { text: `⏳ يجمع جروبات ${all.length} بوت...` });

    try {
      const byId = new Map<string, Entry>();
      for (const { label, sock } of all) {
        try {
          const groups = await Promise.race([
            sock.groupFetchAllParticipating(),
            new Promise<never>((_, rej) => setTimeout(() => rej(new Error("TIMEOUT")), 30000)),
          ]);
          for (const g of Object.values(groups) as any[]) {
            const e: Entry = byId.get(g.id) || { id: g.id, subject: g.subject || "(بدون اسم)", size: g.participants?.length || g.size || 0, bots: [] };
            e.bots.push({ label, sock: sock as any });
            byId.set(g.id, e);
          }
        } catch (err) {
          logger.warn(`⚠️ تعذر جلب جروبات ${label}:`, err);
        }
      }

      const entries = [...byId.values()].sort((a, b) => a.subject.localeCompare(b.subject, "ar"));
      if (!entries.length) {
        await ctx.sock.sendMessage(ctx.chatId, { text: "📭 ما فيه أي مجموعة." });
        return;
      }

      // 🆕 (طلب صريح) فقط الجروبات اللي أحد البوتات فيها مشرف (يقدر يجيب رابطها) — بدون
      // أي جروب بلا رابط. نجرّب كل بوت موجود بالجروب لحد ما ينجح واحد.
      const lines: string[] = [];
      let skipped = 0;
      let index = 1;
      for (const g of entries) {
        let link = "";
        for (const b of g.bots) {
          try {
            const code = await b.sock.groupInviteCode(g.id);
            if (code) {
              link = `https://chat.whatsapp.com/${code}`;
              break;
            }
          } catch {
            /* هذا البوت مو أدمن — نجرّب اللي بعده */
          }
        }
        if (!link) {
          skipped++;
          continue;
        }
        const botsLabel = g.bots.map((b) => (b.label === "main" ? "الرئيسي" : b.label.replace("sub:", "فرعي "))).join("، ");
        lines.push(`${index}. *${g.subject}* (${g.size} عضو)\n🤖 ${botsLabel}\n🔗 ${link}`);
        index++;
      }

      if (!lines.length) {
        await ctx.sock.sendMessage(ctx.chatId, { text: "📭 ما فيه جروب أي بوت فيه مشرف (ما قدرت أجيب أي رابط)." });
        return;
      }

      const header = `📋 *جروبات السيرفر (البوت مشرف فيها):* ${lines.length} جروب — ${all.length} بوت` + (skipped ? `\n(تم تخطي ${skipped} جروب البوت مو مشرف فيه)` : "");
      const chunks: string[] = [];
      let current = header;
      for (const line of lines) {
        if ((current + "\n\n" + line).length > 3500) {
          chunks.push(current);
          current = line;
        } else {
          current = `${current}\n\n${line}`;
        }
      }
      if (current) chunks.push(current);

      for (const chunk of chunks) await ctx.sock.sendMessage(ctx.chatId, { text: chunk });
    } catch (err) {
      logger.error("فشل أمر .جروبات:", err);
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ فشل جلب قائمة الجروبات. جرّب مرة ثانية بعد شوي." });
    }
  },
};

export default command;
