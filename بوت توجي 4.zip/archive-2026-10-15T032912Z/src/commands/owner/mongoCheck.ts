import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { getMongoDb, isMongoConfigured } from "../../database/mongoClient";

/**
 * 🆕 ".فحص_قاعدة_البيانات" — تشخيص حي لاتصال MongoDB على هذا السيرفر تحديدًا:
 * يتأكد إن MONGODB_URI موجود، ثم يعمل كتابة وقراءة فعليتين على مجموعة
 * "healthcheck" ويعرض عدد أقسام البيانات المخزّنة. يخفي الباسورد دائمًا.
 */
function maskUri(uri: string): string {
  // mongodb+srv://user:pass@host/db  →  mongodb+srv://user:••••@host/db
  return uri.replace(/(\/\/[^:/@]+):([^@]+)@/, "$1:••••@");
}

const command: Command = {
  name: "فحص_قاعدة_البيانات",
  aliases: ["mongocheck", "فحص_مونجو", "فحص_مونقو", "dbcheck"],
  category: "المطور",
  description: "يفحص اتصال MongoDB الفعلي على هذا السيرفر ويجرّب قراءة/كتابة حقيقية (بدون إظهار الباسورد)",
  permission: "owner",
  execute: async (ctx) => {
    if (!isMongoConfigured()) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        {
          text:
            `❌ MONGODB_URI غير مضبوط على هذا السيرفر.\n\n` +
            `على Wispbyte: Startup ← Variables ← أضف MONGODB_URI ثم أعد تشغيل البوت.`,
        },
        { quoted: ctx.msg }
      );
      return;
    }

    let result = "";
    try {
      const db = await getMongoDb();
      if (!db) throw new Error("تعذّر الاتصال (راجع الباسورد، وإن Network Access في Atlas يسمح بـ 0.0.0.0/0).");

      const probe = { pingedAt: Date.now() };
      await db.collection("healthcheck").replaceOne({ _id: "probe" as any }, { ...probe }, { upsert: true });
      const back = await db.collection("healthcheck").findOne({ _id: "probe" as any });
      const ok = (back as any)?.pingedAt === probe.pingedAt;

      const parts = await db.collection("bot_state").countDocuments();
      const titles = await db.collection("titles").countDocuments();
      result =
        (ok
          ? "✅ نجحت الكتابة والقراءة الفعلية — الاتصال سليم.\n"
          : "⚠️ الكتابة نجحت لكن القراءة رجّعت قيمة مختلفة.\n") +
        `📦 أجزاء بيانات البوت المخزّنة: ${parts}\n🏷️ الألقاب المخزّنة: ${titles}`;
    } catch (err: any) {
      result = `❌ فشل الفحص: ${err?.message || err}`;
    }

    const dbName = CONFIG.MONGODB_DB || "(من الرابط أو boody_bot)";
    await ctx.sock.sendMessage(
      ctx.chatId,
      {
        text:
          `🔍 *فحص MongoDB (السيرفر الحالي):*\n\n` +
          `الرابط: \`${maskUri(CONFIG.MONGODB_URI)}\`\n` +
          `القاعدة: \`${dbName}\`\n\n` +
          result,
      },
      { quoted: ctx.msg }
    );
  },
};

export default command;
