import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { generateImage } from "../../utils/imageGen";
import { sendErrorMessage } from "../../utils/botMessages";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";
import { isExplicitQuery, EXPLICIT_QUERY_REPLY } from "../../utils/contentFilter";
import { sendCarousel, formatCardFields } from "../../utils/carousel";

/**
 * .رسم <وصف> — يرسم نفس الفكرة بعدة أشكال/أنماط جميلة (أنمي، واقعي، ثلاثي
 * الأبعاد، ألوان مائية، بكسل...) ويرسلها ككاروسيل تتحرك بالإصبع.
 * نفس GEMINI_API_KEY المستخدم بـ.ارسم (ما يحتاج مفتاح جديد).
 * .ارسم (الأمر القديم) يبقى كما هو لرسمة واحدة سريعة.
 */
const IMAGE_MODEL = "gemini-2.5-flash-image";

const STYLES: Array<{ name: string; emoji: string; suffix: string }> = [
  { name: "أنمي", emoji: "🌸", suffix: "high quality anime illustration, vibrant colors, detailed, studio quality" },
  { name: "واقعي", emoji: "📷", suffix: "photorealistic, ultra detailed, cinematic lighting, 8k" },
  { name: "ثلاثي الأبعاد", emoji: "🧊", suffix: "3D render, Pixar-like, soft lighting, high detail" },
  { name: "ألوان مائية", emoji: "🎨", suffix: "delicate watercolor painting, soft gradients, artistic" },
  { name: "بكسل", emoji: "👾", suffix: "retro pixel art, 16-bit, crisp pixels" },
  { name: "نيون", emoji: "🌃", suffix: "cyberpunk neon art, glowing lights, dark background, dramatic" },
];

const command: Command = {
  name: "رسم",
  aliases: ["ارسم_اشكال", "اشكال"],
  category: "اوامر_جانبيه",
  description: "يرسم فكرتك بعدة أشكال جميلة (أنمي/واقعي/3D/مائي...) بكاروسيل. مثال: .رسم قطة فضائية",
  permission: "all",
  execute: async (ctx) => {
    const prompt = ctx.text.trim();
    if (!prompt) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❗ اكتب وصف الرسمة. مثال: .رسم قطة فضائية" }, { quoted: ctx.msg });
      return;
    }
    if (isExplicitQuery(prompt)) {
      await ctx.sock.sendMessage(ctx.chatId, { text: EXPLICIT_QUERY_REPLY }, { quoted: ctx.msg });
      return;
    }
    await ctx.sock.sendMessage(ctx.chatId, { text: "🎨 يرسم لك بعدة أشكال..." });

    try {
      // 4 أشكال فقط وبالتتابع (2 بالتوازي) — الاستضافة ~308MB رام وحصة Gemini المجانية محدودة
      const chosen = STYLES.slice(0, 4);
      const results: PromiseSettledResult<Buffer>[] = [];
      for (let i = 0; i < chosen.length; i += 2) {
        const pair = chosen.slice(i, i + 2);
        results.push(...(await Promise.allSettled(pair.map((st) => generateImage(`${prompt}. Style: ${st.suffix}`)))));
      }

      const cards: Array<{ image: Buffer; body: string }> = [];
      const errors: string[] = [];
      results.forEach((r, i) => {
        if (r.status === "fulfilled" && r.value) {
          cards.push({
            image: r.value,
            body: formatCardFields("رسم", [["🖌️", "الوصف", prompt], [chosen[i].emoji, "الشكل", chosen[i].name]], cards.length + 1),
          });
        } else if (r.status === "rejected") {
          errors.push(r.reason instanceof Error ? r.reason.message : String(r.reason));
        }
      });

      if (!cards.length) throw new Error(errors[0] || "NO_IMAGE_RETURNED");

      const short = CONFIG.BOT_NAME.replace(/\\n|\n/g, " ");
      await sendCarousel(ctx.sock, ctx.chatId, {
        text: `🎨 "${prompt}"\n➜ اسحب لرؤية باقي الأشكال`,
        footer: short,
        quoted: ctx.msg,
        cards: cards.map((c) => ({ ...c, footer: short })),
      });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر رسم:", err);
      await notifyOwnerOfError(ctx.sock, ".رسم", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await sendErrorMessage(ctx.sock, ctx.chatId, ctx.senderJid, err, ctx.metadata?.subject || "خاص", ctx.msg);
    }
  },
};

export default command;
