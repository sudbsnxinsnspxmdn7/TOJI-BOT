import { Command } from "../../handlers/types";
import { searchImages } from "../../utils/imageSearch";
import { downloadFirstImages } from "../../utils/imageCards";
import { isExplicitQuery, EXPLICIT_QUERY_REPLY } from "../../utils/contentFilter";
import { sendErrorMessage } from "../../utils/botMessages";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";
import { sendCarousel, formatCardFields } from "../../utils/carousel";
import { CONFIG } from "../../config/config";

/**
 * .صور / .صورة <كلمة> — يبحث ويرسل 5 صور ككاروسيل تتحرك بالإصبع
 * (يمين/يسار) بدل 5 رسائل متتالية. الصور تُحمَّل بهيدر متصفح ثم تُرفع
 * كـbuffer (روابط البحث الخام تفشل غالبًا عند تمريرها لواتساب مباشرة).
 */
const MAX_IMAGES = 5;
const MAX_IMAGE_CANDIDATES = 16;

const command: Command = {
  name: "صور",
  aliases: ["صورة_بحث", "img", "image"],
  category: "اوامر_جانبيه",
  description: "بحث عن صور بأي كلمة — 5 صور بكاروسيل. مثال: .صور ميوك",
  permission: "all",
  execute: async (ctx) => {
    const query = ctx.text.trim();
    if (!query) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ اكتب كلمة بحث بعد الأمر. مثال: .صور قطط" }, { quoted: ctx.msg });
      return;
    }

    if (isExplicitQuery(query)) {
      await ctx.sock.sendMessage(ctx.chatId, { text: EXPLICIT_QUERY_REPLY }, { quoted: ctx.msg });
      return;
    }

    try {
      const urls = await searchImages(query, MAX_IMAGE_CANDIDATES);
      if (!urls.length) {
        await ctx.sock.sendMessage(ctx.chatId, { text: "❌ ما لقيت صور لهالكلمة." }, { quoted: ctx.msg });
        return;
      }

      const images = await downloadFirstImages(urls, MAX_IMAGES);
      if (!images.length) {
        await notifyOwnerOfError(ctx.sock, ".صور", `كل الصور فشلت لـ"${query}"`, { chatId: ctx.chatId, senderJid: ctx.senderJid });
        await ctx.sock.sendMessage(ctx.chatId, { text: "❌ لقيت صور بس ما قدرت أحمّل ولا وحدة. جرّب كلمة ثانية." }, { quoted: ctx.msg });
        return;
      }

      const short = CONFIG.BOT_NAME.replace(/\\n|\n/g, " ");
      await sendCarousel(ctx.sock, ctx.chatId, {
        text: `🖼️ صور "${query}"\n➜ اسحب لرؤية باقي الصور`,
        footer: short,
        quoted: ctx.msg,
        cards: images.map((image, i) => ({
          image,
          footer: short,
          body: formatCardFields("صورة", [["🔎", "البحث", query]], i + 1),
        })),
      });
    } catch (err) {
      logger.error("فشل أمر .صور:", err);
      await sendErrorMessage(ctx.sock, ctx.chatId, ctx.senderJid, err, ctx.metadata?.subject || "خاص", ctx.msg);
    }
  },
};

export default command;
