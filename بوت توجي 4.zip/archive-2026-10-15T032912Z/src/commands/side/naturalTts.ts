import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";
import { toOpusVoiceNote } from "../../utils/ffmpegMedia";
import { fetchTtsBuffer } from "../../utils/googleTts";

// 🔧 تكملة لأمر .صوت الموجود أصلًا (Google Translate TTS مجاني بس صوته
// آلي وروبوتي). هذا أمر إضافي بصوت طبيعي أقرب للبشري (ElevenLabs)،
// يحتاج مفتاح — لو ما فيه مفتاح، يقترح يستخدم .صوت المجاني بدله.
const DEFAULT_VOICE_ID = "21m00Tcm4TlvDq8ikWAM"; // "Rachel" الصوت الافتراضي بـElevenLabs

const command: Command = {
  name: "قول",
  category: "اوامر_جانبيه",
  description: "يحوّل نص لصوت طبيعي ويرسله كبصمة صوتية (PTT). مثال: .قول مرحبا",
  permission: "all",
  execute: async (ctx) => {
    const text = ctx.text.trim();
    if (!text) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❗ اكتب النص بعد الأمر. مثال: .قول مرحبا كيف حالك" }, { quoted: ctx.msg });
      return;
    }

    if (!CONFIG.ELEVENLABS_API_KEY) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text:
          "❌ هذا الأمر يحتاج مفتاح بملف .env (ELEVENLABS_API_KEY) لصوت طبيعي.\n" +
          "خذ مفتاح من: https://elevenlabs.io → Profile → API Keys\n\n" +
          "💡 بالانتظار، جرّب أمر .صوت (نفس الفكرة بصوت آلي مجاني بالكامل).",
      });
      return;
    }

    // محاولة 1: ElevenLabs (صوت طبيعي). أي فشل بالمفتاح/الرصيد → نحوّل تلقائيًا
    // لصوت Google المجاني بدل ما نترك المستخدم بخطأ.
    let elevenFailure = "";
    try {
      const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${DEFAULT_VOICE_ID}`, {
        method: "POST",
        headers: {
          "xi-api-key": CONFIG.ELEVENLABS_API_KEY,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          text: text.slice(0, 500),
          model_id: "eleven_multilingual_v2",
        }),
      });

      if (!res.ok) {
        const errText = await res.text();
        const hint =
          res.status === 401 && /missing_permissions|text_to_speech/i.test(errText)
            ? " — المفتاح ما عنده صلاحية Text to Speech: من elevenlabs.io → API Keys أنشئ مفتاحًا جديدًا وفعّل Text to Speech (أو اختر Unrestricted)."
            : res.status === 401
            ? " — المفتاح غير صحيح."
            : res.status === 402 || res.status === 429
            ? " — الرصيد/الحد الشهري خلص."
            : "";
        elevenFailure = `ELEVENLABS_${res.status}${hint}`;
        throw new Error(`ELEVENLABS_${res.status}: ${errText.slice(0, 200)}`);
      }

      const mp3 = Buffer.from(await res.arrayBuffer());
      // رسالة صوتية فعلية لازم تكون OGG/Opus؛ لو فشل التحويل نرسله كملف صوتي عادي
      try {
        const ogg = await toOpusVoiceNote(mp3, "mp3");
        await ctx.sock.sendMessage(ctx.chatId, { audio: ogg, mimetype: "audio/ogg; codecs=opus", ptt: true }, { quoted: ctx.msg });
      } catch (convErr) {
        logger.warn("تعذّر تحويل صوت ElevenLabs إلى opus — يُرسل كملف mp3.", convErr);
        await ctx.sock.sendMessage(ctx.chatId, { audio: mp3, mimetype: "audio/mpeg", ptt: false }, { quoted: ctx.msg });
      }
      return;
    } catch (err) {
      logger.warn(`ElevenLabs فشل (${elevenFailure || "خطأ شبكة"}) — نحوّل لصوت Google المجاني.`);
      if (elevenFailure) {
        await notifyOwnerOfError(ctx.sock, ".قول", elevenFailure, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      }
    }

    // محاولة 2: Google TTS المجاني (احتياطي)
    try {
      const audio = await fetchTtsBuffer(text);
      await ctx.sock.sendMessage(ctx.chatId, { audio, mimetype: "audio/mpeg", ptt: false }, { quoted: ctx.msg });
    } catch (err) {
      logger.error("فشل أمر قول (الاحتياطي أيضًا):", err);
      await ctx.sock.sendMessage(ctx.chatId, { text: "❌ تعذّر توليد الصوت حاليًا. حاول لاحقًا أو بنص أقصر." }, { quoted: ctx.msg });
    }
  },
};

export default command;
