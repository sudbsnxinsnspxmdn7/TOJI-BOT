import { Command } from "../../handlers/types";
import { downloadMediaMessage } from "@whiskeysockets/baileys";
import crypto from "crypto";
import { sendErrorMessage } from "../../utils/botMessages";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError, buildQuotedMessage } from "../../utils/helpers";
import { addStickerPackExif } from "../../utils/stickerExif";

/**
 * .ملكيه <الاسم> — رد على ملصق: يعيد إرساله باسم الحزمة/الناشر = الاسم الجديد
 * (تظهر عند فتح الملصق بواتساب). الصورة نفسها ما تتغير، فقط بيانات الملكية.
 * مثال: .ملكيه ميهوك
 */
const command: Command = {
  name: "ملكيه",
  aliases: ["ملكية", "ملكيه_ملصق"],
  category: "اوامر_جانبيه",
  description: "يغيّر اسم صاحب/حزمة الملصق. رد على ملصق: .ملكيه ميهوك",
  permission: "all",
  execute: async (ctx) => {
    const quotedSticker = ctx.quoted?.stickerMessage;
    const stickerMsg = quotedSticker || ctx.msg.message?.stickerMessage;
    const name = ctx.text.trim().slice(0, 40);

    if (!stickerMsg || !name) {
      await ctx.sock.sendMessage(
        ctx.chatId,
        { text: "⚠️ رد على ملصق بالأمر مع الاسم الجديد.\nمثال: .ملكيه ميهوك" },
        { quoted: ctx.msg }
      );
      return;
    }

    try {
      const source = quotedSticker ? buildQuotedMessage(ctx.msg) ?? ctx.msg : ctx.msg;
      const buffer = (await downloadMediaMessage(
        source,
        "buffer",
        {},
        { logger: logger as any, reuploadRequest: ctx.sock.updateMediaMessage }
      )) as Buffer;

      const out = await addStickerPackExif(buffer, crypto.randomUUID(), name, name);
      await ctx.sock.sendMessage(ctx.chatId, { sticker: out }, { quoted: ctx.msg });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر ملكيه:", err);
      await notifyOwnerOfError(ctx.sock, ".ملكيه", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await sendErrorMessage(ctx.sock, ctx.chatId, ctx.senderJid, err, ctx.metadata?.subject || "خاص", ctx.msg);
    }
  },
};

export default command;
