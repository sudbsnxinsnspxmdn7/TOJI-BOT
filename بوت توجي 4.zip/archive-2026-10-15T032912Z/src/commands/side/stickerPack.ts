import { Command } from "../../handlers/types";
import { CONFIG } from "../../config/config";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";
import { searchImages, toEnglishQuery } from "../../utils/imageSearch";
import { downloadFirstImages } from "../../utils/imageCards";
import { isExplicitQuery, EXPLICIT_QUERY_REPLY } from "../../utils/contentFilter";
import { sendStickerPack } from "../../utils/stickerPackMessage";
import { packProgressText, packDoneText, sendErrorMessage } from "../../utils/botMessages";

/**
 * .حزمه <كلمة> — يبحث (بالعربي والإنجليزي ومن عدة مصادر) عن 30 صورة للكلمة،
 * يحوّلها لملصقات ويرسلها كحزمة ملصقات واتساب الأصلية (بطاقة + زر "عرض مجموعة
 * الملصقات") — مو ملف ولا ملصقات واحد واحد.
 * مثال: .حزمه غوجو ساتورو
 */
const TARGET = 30;
const MIN_OK = 6; // أقل من هذا العدد نعتبر البحث فاشلًا بدل ما نرسل حزمة هزيلة

const command: Command = {
  name: "حزمه",
  aliases: ["حزمة", "ملصقات", "stickers", "pack"],
  category: "اوامر_جانبيه",
  description: "حزمة ملصقات واتساب (30 ملصق) بأي كلمة. مثال: .حزمه غوجو ساتورو",
  permission: "all",
  execute: async (ctx) => {
    const query = ctx.text.trim();
    const groupName = ctx.metadata?.subject || "خاص";

    if (!query) {
      await ctx.sock.sendMessage(ctx.chatId, { text: "❗ اكتب اسم الحزمة. مثال: .حزمه غوجو ساتورو" }, { quoted: ctx.msg });
      return;
    }
    if (isExplicitQuery(query)) {
      await ctx.sock.sendMessage(ctx.chatId, { text: EXPLICIT_QUERY_REPLY }, { quoted: ctx.msg });
      return;
    }

    await ctx.sock.sendMessage(
      ctx.chatId,
      { text: packProgressText(ctx.senderJid, query, groupName, TARGET), mentions: [ctx.senderJid] },
      { quoted: ctx.msg }
    );

    try {
      // بحث بالعربي والإنجليزي (الترجمة تضيف اسم الشخصية + العمل) — على طبقات حسب الدقة:
      // الطبقة 1 (الأدق): Tavily الدلالي + عبارة بين علامتي تنصيص مع "sticker"
      // الطبقة 2: الاسم الإنجليزي كما هو ثم الكلمة العربية الأصلية
      // الطبقة 3 (للتعبئة فقط لو ما كفت): توسعة بـanime/art
      // ما عاد ندمج الاستعلامات العامة (png/art) مع الدقيقة — كانت سبب النتائج العشوائية.
      let english = query;
      try {
        english = await toEnglishQuery(query);
      } catch {
        /* نكمل بالكلمة الأصلية */
      }

      const tavilyImages = async (q: string): Promise<string[]> => {
        if (!CONFIG.TAVILY_API_KEY) return [];
        try {
          const res = await fetch("https://api.tavily.com/search", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            signal: AbortSignal.timeout(12_000),
            body: JSON.stringify({ api_key: CONFIG.TAVILY_API_KEY, query: q, search_depth: "basic", include_images: true, max_results: 5 }),
          });
          if (!res.ok) return [];
          const json: any = await res.json();
          return (json?.images || []).map((x: any) => (typeof x === "string" ? x : x?.url)).filter(Boolean);
        } catch {
          return [];
        }
      };

      const safe = async (p: Promise<string[]>) => p.catch(() => [] as string[]);
      const tier1Lists = await Promise.all([
        safe(tavilyImages(`${english} stickers`)),
        safe(searchImages(`"${english}" sticker`, 40)),
        safe(tavilyImages(english)),
      ]);
      const tier2Lists = await Promise.all([safe(searchImages(english, 40)), safe(searchImages(query, 40))]);
      const tier3Lists = await Promise.all([safe(searchImages(`${english} anime art`, 30))]);

      const seen = new Set<string>();
      const interleave = (lists: string[][]): string[] => {
        const out: string[] = [];
        const longest = Math.max(0, ...lists.map((l) => l.length));
        for (let i = 0; i < longest; i++) {
          for (const l of lists) {
            if (l[i] && !seen.has(l[i])) {
              seen.add(l[i]);
              out.push(l[i]);
            }
          }
        }
        return out;
      };
      const urls = [...interleave(tier1Lists), ...interleave(tier2Lists), ...interleave(tier3Lists)];
      if (!urls.length) throw new Error("لا توجد نتائج بحث لهذه الكلمة");

      const images = await downloadFirstImages(urls.slice(0, 120), TARGET, 8);
      if (images.length < MIN_OK) throw new Error(`لقيت ${images.length} صورة فقط من أصل ${TARGET} — جرّب كلمة أوضح`);

      const count = await sendStickerPack(ctx.sock, ctx.chatId, {
        name: query.slice(0, 40),
        publisher: "BOODY BOT",
        description: `حزمة ${query}`,
        images,
        mentions: [ctx.senderJid],
        quoted: ctx.msg,
      });

      await ctx.sock.sendMessage(ctx.chatId, {
        text: packDoneText(ctx.senderJid, query, groupName, count),
        mentions: [ctx.senderJid],
      });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      logger.error("فشل أمر حزمه:", err);
      await notifyOwnerOfError(ctx.sock, ".حزمه", reason, { chatId: ctx.chatId, senderJid: ctx.senderJid });
      await sendErrorMessage(ctx.sock, ctx.chatId, ctx.senderJid, err, groupName, ctx.msg);
    }
  },
};

export default command;
