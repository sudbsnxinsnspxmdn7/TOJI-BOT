import { Command } from "../../handlers/types";
import { detectPlatform, resolveVideo, downloadBuffer } from "../../utils/downloader";
import { ytdlpDownload } from "../../utils/ytdlp";
import { sendErrorMessage } from "../../utils/botMessages";
import { ensureWhatsAppMp4 } from "../../utils/ffmpegMedia";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";

/**
 * 🔧 ملاحظة مهمة: هذا الأمر كان اسمه المقترح ".تنزيل"، لكن هذا الاسم
 * مستخدم أصلًا لأمر إداري مختلف تمامًا (تنزيل مشرف من الإشراف —
 * src/commands/admin/demote.ts). لتفادي التعارض بين الأمرين تم اعتماد
 * اسم ".تحميل" لهذا الأمر (تحميل فيديو)، ووُضع في قسم الأدوات كما طُلب،
 * دون أي تعديل على أمر .تنزيل (تنزيل الإشراف) الموجود مسبقًا.
 */

function progressBar(percent: number): string {
  const total = 10;
  const filled = Math.round((percent / 100) * total);
  return "█".repeat(filled) + "░".repeat(total - filled);
}

function looksLikeVideo(b: Buffer): boolean {
  if (!b || b.length < 20_000) return false;
  const head4 = b.subarray(4, 8).toString("latin1");
  const isMp4Family = head4 === "ftyp" || head4 === "moov" || head4 === "mdat" || head4 === "free" || head4 === "wide";
  const isWebm = b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3;
  return isMp4Family || isWebm;
}

const command: Command = {
  name: "تحميل",
  aliases: ["تنزيل_فيديو", "download", "دلود"],
  category: "ادوات",
  description: "تحميل فيديو من تيك توك، انستقرام، يوتيوب، فيسبوك، تويتر وغيرها. مثال: .تحميل <رابط>",
  permission: "all",
  execute: async (ctx) => {
    const url = ctx.args[0];

    if (!url || !/^https?:\/\//i.test(url)) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ أرسل رابط فيديو صحيح بعد الأمر.\nمثال: .تحميل https://vt.tiktok.com/xxxxx",
        __skipBrand: true,
      } as any);
      return;
    }

    const platform = detectPlatform(url);
    if (!platform) {
      // 🔧 إصلاح (سبب "الأمر ما يرد ولا يعطي أي تفسير أحيانًا"): الكود
      // القديم كان يحذف رسالة الرابط الغير مدعوم بصمت تام لو نجح الحذف
      // (البوت مشرف بالمجموعة)، ويرسل رسالة التفسير فقط لو *فشل* الحذف —
      // يعني بأغلب الحالات العادية (بوت مشرف) المستخدم ما يشوف أي رد
      // إطلاقًا ويحس إن الأمر "ما يشتغل". الحين نرسل رسالة التفسير دائمًا
      // بغض النظر عن نجاح/فشل الحذف، والحذف يبقى إضافة تنظيفية اختيارية بس.
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ الرابط غير صالح أو غير مدعوم.",
        __skipBrand: true,
      } as any);
      if (ctx.metadata) {
        try {
          await ctx.sock.sendMessage(ctx.chatId, { delete: ctx.msg.key });
        } catch {
          /* تجاهل بأمان — الحذف تنظيف اختياري، المستخدم أصلًا استلم التفسير أعلاه */
        }
      }
      return;
    }

    // 🔧 (طلب صريح: إزالة الأزرار عن رسالة "جاري التحميل") — البراندنج
    // التلقائي (createBrandedSock) كان يحوّل هذي الرسالة النصية البسيطة
    // تلقائيًا لرسالة أزرار (لأنها {text} بس، بدون __skipBrand). نمنعه هنا.
    const sent = await ctx.sock.sendMessage(ctx.chatId, {
      text: `📥 جاري التحميل...\n\n${progressBar(0)} 0%`,
      __skipBrand: true,
    } as any);
    const editKey = sent?.key;

    const editText = async (text: string) => {
      if (!editKey) return;
      try {
        await ctx.sock.sendMessage(ctx.chatId, { text, edit: editKey } as any);
      } catch (err) {
        logger.error("فشل تعديل رسالة التحميل:", err);
      }
    };

    try {
      let buffer: Buffer;
      try {
        const resolved = await resolveVideo(url, platform);
        buffer = await downloadBuffer(
          resolved.videoUrl,
          (percent) => {
            editText(`📥 جاري التحميل...\n\n${progressBar(percent)} ${percent}%`);
          },
          platform
        );
        // 🆕 (سبب "تم التحميل وما وصل فيديو"): بعض الروابط ترجّع صفحة خطأ/ملف ناقص بدل الفيديو.
        // نتأكد إنه ملف فيديو فعلًا (mp4/webm/mov) وبحجم معقول، وإلا ننتقل لـyt-dlp.
        if (!looksLikeVideo(buffer)) throw new Error("الملف المحمَّل مو فيديو صالح");
      } catch (primaryErr: any) {
        // 🆕 احتياطي شامل: yt-dlp (يوتيوب/فيسبوك/تويتر/ريديت/وغيرها + تيك توك/انستا لو الخدمات تعطلت)
        logger.warn("⚠️ المسار الأساسي فشل، نجرّب yt-dlp:", primaryErr?.message || primaryErr);
        await editText("📥 المصدر الأول تعثّر، أجرّب طريقة ثانية...");
        try {
          buffer = (await ytdlpDownload(url, "video")).buffer;
        } catch (fallbackErr: any) {
          fallbackErr.message = `${primaryErr?.message || primaryErr} | yt-dlp: ${fallbackErr?.message || fallbackErr}`;
          throw fallbackErr;
        }
      }

      // 🆕 يضمن H.264/AAC حتى يفتح الفيديو بواتساب (بدل "خطأ بالتشفير")
      buffer = await ensureWhatsAppMp4(buffer).catch(() => buffer);

      await ctx.sock.sendMessage(ctx.chatId, {
        video: buffer,
        mimetype: "video/mp4",
        caption: `✅ تم التحميل بنجاح — ${
          platform === "tiktok" ? "TikTok" : platform === "instagram" ? "Instagram" : "رابط مباشر"
        } 📥`,
      });

      await editText("✅ تم التحميل بنجاح");
    } catch (err: any) {
      logger.error("فشل أمر .تحميل:", err);

      // 🆕 (بسبب "أكثر من مرة يقولي تعذر ومدري ليش"): كنا نسجّل الخطأ
      // الحقيقي بسجلات السيرفر فقط (logger.error) — وأغلب أصحاب
      // الاستضافات المجانية (مثل Katabump) ما يفتحون الـ Console أبدًا أو
      // ما يعرفون كيف. الحين نبعت تفاصيل الخطأ الحقيقي (رسالة الخطأ
      // الفعلية من الشبكة/الـ API) مباشرة لرقم المطور بالخاص تلقائيًا،
      // فيوصلك التشخيص الدقيق فورًا بدون فتح أي console.
      await notifyOwnerOfError(ctx.sock, ".تحميل", String(err?.message || err), {
        chatId: ctx.chatId,
        senderJid: ctx.senderJid,
      });

      const reason =
        err?.message === "NOT_A_VIDEO"
          ? "⚠️ الرابط يشير إلى صورة/منشور غير فيديو، الأمر يدعم الفيديوهات فقط."
          : err?.message === "NOT_FOUND"
          ? "⚠️ الفيديو غير موجود أو محذوف أو الرابط غير صحيح."
          : err?.message === "TIMEOUT"
          ? "⚠️ انتهت المهلة أثناء التحميل، جرّب مرة أخرى."
          : `❌ تعذر تحميل الفيديو حاليًا (${String(err?.message || "خطأ غير معروف")}). جرّب لاحقًا أو برابط آخر.`;

      await sendErrorMessage(ctx.sock, ctx.chatId, ctx.senderJid, reason.replace(/^[⚠️❌\s]+/u, ""), ctx.metadata?.subject || "خاص", ctx.msg);
    }
  },
};

export default command;
