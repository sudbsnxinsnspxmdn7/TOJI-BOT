import { Command } from "../../handlers/types";
import { sendErrorMessage, editSearchingText, editFoundText } from "../../utils/botMessages";
import { logger } from "../../utils/logger";
import { notifyOwnerOfError } from "../../utils/helpers";
import { searchEditVideos } from "../../utils/editSearch";
import { sendCarousel, formatCardFields } from "../../utils/carousel";
import { CONFIG } from "../../config/config";

/**
 * .ايديت <كلمة> — يرسل 5 فيديوهات تصميم/edit كبطاقات كاروسيل تتحرك
 * بالإصبع يمين/يسار (نفس شكل البوت الثاني)، كل بطاقة فيها: العنوان +
 * الناشر + المصدر + زر القناة.
 *
 * المصادر: تيك توك (tikwm + وسطاء) ثم يوتيوب تلقائيًا لو نقص العدد.
 * لو ما انرسل الكاروسيل (واتساب رفضه) يرجع لإرسال الفيديوهات متتالية.
 */
const RANDOM_TOPICS = ["anime edit", "amv edit", "تصميم انمي", "تصميم كرتون", "edit capcut"];
const CARD_COUNT = 5;

const command: Command = {
  name: "ايديت",
  aliases: ["edit", "تصميم", "اديت", "إيديت"],
  category: "ادوات",
  description: "5 فيديوهات تصميم/edit بكاروسيل تتحرك بالإصبع. مثال: .ايديت لوفي",
  permission: "all",
  execute: async (ctx) => {
    const query = ctx.text?.trim() || RANDOM_TOPICS[Math.floor(Math.random() * RANDOM_TOPICS.length)];

    const groupName = ctx.metadata?.subject || "خاص";
    await ctx.sock.sendMessage(ctx.chatId, { text: editSearchingText(CARD_COUNT, query, groupName) }, { quoted: ctx.msg });

    const { videos, errors } = await searchEditVideos(query, CARD_COUNT);

    if (!videos.length) {
      logger.error("فشل أمر .ايديت من كل المصادر:", errors.join(" | "));
      await notifyOwnerOfError(ctx.sock, ".ايديت", errors.join(" | ") || "NO_RESULTS", {
        chatId: ctx.chatId,
        senderJid: ctx.senderJid,
      });
      await sendErrorMessage(ctx.sock, ctx.chatId, ctx.senderJid, "ما لقيت تصميم من أي مصدر حاليًا", ctx.metadata?.subject || "خاص", ctx.msg);
      return;
    }

    const short = CONFIG.BOT_NAME.replace(/\\n|\n/g, " ");
    await sendCarousel(ctx.sock, ctx.chatId, {
      text: "\u200e", // النص العلوي فاضي — كل بطاقة تحمل قالبها ورقم الفيديو (1 → 5)
      footer: short,
      quoted: ctx.msg,
      cards: videos.map((v, i) => ({
        video: v.buffer,
        footer: short,
        body:
          editFoundText(i + 1, videos.length, query, groupName) +
          `\nـ⌬┋ _*المصدر: ${v.source}*_` +
          `\nـ⌬┋ _*${v.title.slice(0, 60)}*_`,
        buttons: v.url ? [{ type: "url", label: "فتح الاصل", value: v.url }] : undefined,
      })),
    });
  },
};

export default command;
