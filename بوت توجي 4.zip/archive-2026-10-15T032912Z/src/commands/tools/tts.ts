import { Command } from "../../handlers/types";
import { fetchTtsBuffer } from "../../utils/googleTts";

const command: Command = {
  name: "صوت",
  aliases: ["tts"],
  category: "ادوات",
  description: "تحويل نص إلى مقطع صوتي. مثال: .صوت مرحبا بكم",
  permission: "all",
  execute: async (ctx) => {
    if (!ctx.text) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "⚠️ اكتب النص المراد تحويله بعد الأمر.\nمثال: .صوت مرحبا بكم",
      });
      return;
    }

    try {
      const audio = await fetchTtsBuffer(ctx.text);
      await ctx.sock.sendMessage(ctx.chatId, {
        audio,
        mimetype: "audio/mpeg",
        // ⚠️ ptt:true (رسالة صوتية) يتطلب من واتساب أن يكون الصوت بصيغة
        // OGG/Opus فعليًا، وإلا يظهر خطأ "هذا المقطع الصوتي غير متوفر" عند
        // المستلم رغم وصول الرسالة بنجاح. خدمة Google TTS ترجع MP3، فنرسله
        // كملف صوتي عادي (ptt:false) بدل رسالة صوتية، وبكذا يشتغل التشغيل
        // بشكل طبيعي دون الحاجة لتحويل الصيغة عبر ffmpeg (غير مضمون توفره
        // على استضافات مجانية مثل Katabump).
        ptt: false,
      });
    } catch (err) {
      await ctx.sock.sendMessage(ctx.chatId, {
        text: "❌ تعذر تحويل النص إلى صوت حاليًا. حاول لاحقًا أو بنص أقصر.",
      });
    }
  },
};

export default command;
