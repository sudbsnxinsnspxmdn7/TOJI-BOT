import fs from "fs";
import path from "path";

/**
 * 🔧 سبب أساسي لبطء البوت وانقطاع اتصاله: lowdb FileSync يكتب ملف db.json *كاملًا*
 * بشكل متزامن (يوقف كل شي) مع كل .write() — وبعض الأوامر/الإحصائيات تكتب مع كل
 * رسالة. لما الملف يكبر يتجمّد البوت عشرات الملّي ثانية لكل رسالة، فتتأخر الردود
 * وقد يفوّت نبضات الاتصال (keep-alive) فيفصل واتساب الجلسة.
 * هذا المحوّل يجمّع الكتابات: يحفظ آخر حالة بالذاكرة ويكتب للقرص مرة كل ثانية ونصف
 * كحد أقصى (كتابة ذرّية عبر ملف مؤقت ثم rename)، ويكتب فورًا عند إغلاق العملية.
 */
export class DebouncedFileAdapter<T extends object> {
  private timer: NodeJS.Timeout | null = null;
  private latest: T | null = null;

  // 🆕 (مزامنة MongoDB) — onWrite يُستدعى بكل write() بالتوازي مع الحفظ
  // المحلي (ما يوقف ولا يبطئ الحفظ المحلي أبدًا). onShutdown يُنتظر (بمهلة
  // قصوى) عند SIGINT/SIGTERM لرفع آخر التغييرات لـ MongoDB قبل إغلاق العملية —
  // مهم على Wispbyte لأن زر Stop/Restart يرسل SIGTERM.
  constructor(
    private file: string,
    private defaultValue: T,
    private delayMs = 1500,
    private onWrite?: (data: T) => void,
    private onShutdown?: () => Promise<void>
  ) {
    const flush = () => this.flushSync();
    process.once("exit", flush);
    const graceful = async () => {
      flush();
      try {
        await this.onShutdown?.();
      } catch {
        /* لا نمنع الإغلاق */
      }
      process.exit(0);
    };
    process.once("SIGINT", () => void graceful());
    process.once("SIGTERM", () => void graceful());
  }

  read(): T {
    try {
      const raw = fs.readFileSync(this.file, "utf-8");
      return raw.trim() ? (JSON.parse(raw) as T) : this.defaultValue;
    } catch (err: any) {
      if (err?.code === "ENOENT") {
        this.latest = this.defaultValue;
        this.flushSync();
        return this.defaultValue;
      }
      // ملف تالف: نحتفظ بنسخة منه بدل ما نمسحه بصمت
      try {
        fs.copyFileSync(this.file, `${this.file}.corrupt-${Date.now()}`);
      } catch {
        /* تجاهل */
      }
      return this.defaultValue;
    }
  }

  write(data: T): void {
    this.latest = data;
    try {
      this.onWrite?.(data);
    } catch {
      /* أي خطأ بالنسخ الاحتياطي السحابي ما يوقف الحفظ المحلي أبدًا */
    }
    if (this.timer) return;
    this.timer = setTimeout(() => {
      this.timer = null;
      this.flushSync();
    }, this.delayMs);
    this.timer.unref?.();
  }

  flushSync(): void {
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    if (!this.latest) return;
    try {
      const tmp = `${this.file}.tmp`;
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(tmp, JSON.stringify(this.latest));
      fs.renameSync(tmp, this.file);
    } catch (err) {
      console.error("تعذر حفظ قاعدة البيانات:", err);
    }
  }
}
