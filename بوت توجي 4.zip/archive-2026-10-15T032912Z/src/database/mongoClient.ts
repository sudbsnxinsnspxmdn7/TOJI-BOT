/**
 * 🍃 اتصال MongoDB المركزي (MongoDB Atlas) — بديل Supabase بالكامل.
 *
 * - يقرأ MONGODB_URI من متغيرات البيئة (على Wispbyte: Startup → Variables).
 * - اتصال واحد مشترك لكل البوت (Singleton) مع Pool صغير يناسب رام 512MB.
 * - أي فشل اتصال لا يوقف البوت أبدًا: نرجع null ونكمل بالملف المحلي.
 */
import { MongoClient, Db } from "mongodb";
import { CONFIG } from "../config/config";
import { logger } from "../utils/logger";

export function isMongoConfigured(): boolean {
  return Boolean(CONFIG.MONGODB_URI);
}

let client: MongoClient | null = null;
let connecting: Promise<Db | null> | null = null;

/** اسم قاعدة البيانات: من MONGODB_DB أو من الرابط نفسه أو "boody_bot". */
function resolveDbName(): string {
  if (CONFIG.MONGODB_DB) return CONFIG.MONGODB_DB;
  try {
    // mongodb+srv://user:pass@host/dbname?opts  →  dbname
    const m = CONFIG.MONGODB_URI.match(/^mongodb(?:\+srv)?:\/\/[^/]+\/([^?]+)/i);
    if (m && m[1]) return decodeURIComponent(m[1]);
  } catch {
    /* تجاهل */
  }
  return "boody_bot";
}

/** يرجع Db جاهز، أو null لو MONGODB_URI ناقص/الاتصال فشل (بدون رمي أخطاء). */
export async function getMongoDb(): Promise<Db | null> {
  if (!isMongoConfigured()) return null;
  if (client) return client.db(resolveDbName());
  if (connecting) return connecting;

  connecting = (async () => {
    const c = new MongoClient(CONFIG.MONGODB_URI, {
      maxPoolSize: 5,
      minPoolSize: 0,
      serverSelectionTimeoutMS: 12_000,
      connectTimeoutMS: 12_000,
      socketTimeoutMS: 45_000,
      retryWrites: true,
      appName: "boody-bot",
    });
    try {
      await c.connect();
      await c.db(resolveDbName()).command({ ping: 1 });
      client = c;
      logger.info(`✅ متصل بـ MongoDB (قاعدة: ${resolveDbName()}).`);
      return c.db(resolveDbName());
    } catch (err: any) {
      logger.warn(`⚠️ تعذّر الاتصال بـ MongoDB: ${err?.message || err}`);
      try {
        await c.close();
      } catch {
        /* تجاهل */
      }
      return null;
    } finally {
      connecting = null;
    }
  })();
  return connecting;
}

export async function closeMongo(): Promise<void> {
  const c = client;
  client = null;
  if (c) {
    try {
      await c.close();
    } catch {
      /* تجاهل */
    }
  }
}
