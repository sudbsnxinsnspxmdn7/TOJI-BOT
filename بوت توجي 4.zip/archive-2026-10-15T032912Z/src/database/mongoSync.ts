/**
 * 🔄 مزامنة قاعدة البيانات المحلية (lowdb → db.json) مع MongoDB.
 *
 * الفكرة: lowdb يظل هو الواجهة السريعة المتزامنة (صفر تغيير على أي أمر)،
 * وMongoDB هو المخزن الدائم الحقيقي:
 *   • كل تغيير محلي يُرفع لـ MongoDB بعد ~4 ثواني (Debounce) — فقط الأقسام
 *     اللي تغيّرت فعلًا (مقارنة بصمة md5)، فالحمل خفيف جدًا.
 *   • كل قسم رئيسي (groups / points / economy ...) يتخزن كمستند مستقل
 *     كنص JSON (وبأجزاء لو كبر) — يتفادى حد 16MB لمستند واحد وأي مشكلة
 *     بمفاتيح فيها نقاط مثل 9647xxx@s.whatsapp.net.
 *   • عند الإقلاع: لو MongoDB فيه بيانات نستعيدها (حتى لو الاستضافة مسحت
 *     الملفات). لو MongoDB فاضي وعندنا بيانات محلية نرفعها (ترحيل أول مرة).
 *   • عند الإيقاف (SIGTERM/SIGINT) نرفع آخر تغييرات قبل الإغلاق.
 */
import crypto from "crypto";
import { Collection } from "mongodb";
import { getMongoDb, isMongoConfigured } from "./mongoClient";
import { logger } from "../utils/logger";

const COLLECTION = "bot_state";
const PUSH_DELAY_MS = 4000;
// 3 مليون حرف ≈ حتى 12MB بايت بأسوأ حالة (UTF-8) — أقل من حد 16MB بأمان
const CHUNK_CHARS = 3_000_000;

interface StateDoc {
  _id: string; // `${key}::${partIndex}`
  key: string;
  part: number;
  parts: number;
  json: string;
  updatedAt: Date;
}

let stateProvider: (() => unknown) | null = null;
let ready = false;
let pushTimer: NodeJS.Timeout | null = null;
let pushing: Promise<void> | null = null;
let dirtyWhilePushing = false;
const lastPushed = new Map<string, string>(); // key → md5 للنص المرفوع

function md5(s: string): string {
  return crypto.createHash("md5").update(s).digest("hex");
}

/** يحدد من أين نقرأ الحالة الحالية وقت الرفع (بدل التقاط نسخة قديمة). */
export function setStateProvider(fn: () => unknown): void {
  stateProvider = fn;
}

/** يفعّل الرفع الدوري بعد انتهاء الاستعادة الأولية (لا نرفع قبلها أبدًا). */
export function enableSync(): void {
  ready = true;
}

async function getColl(): Promise<Collection<StateDoc> | null> {
  const db = await getMongoDb();
  return db ? db.collection<StateDoc>(COLLECTION) : null;
}

function splitChunks(json: string): string[] {
  if (json.length <= CHUNK_CHARS) return [json];
  const out: string[] = [];
  for (let i = 0; i < json.length; i += CHUNK_CHARS) out.push(json.slice(i, i + CHUNK_CHARS));
  return out;
}

/** يرفع الأقسام المتغيرة فقط. يرجع true لو نجح. */
async function pushNow(): Promise<boolean> {
  if (!stateProvider) return false;
  const coll = await getColl();
  if (!coll) return false;

  const state = (stateProvider() || {}) as Record<string, unknown>;
  const ops: any[] = [];
  const newHashes = new Map<string, string>();

  for (const key of Object.keys(state)) {
    const json = JSON.stringify(state[key]) ?? "null";
    const h = md5(json);
    newHashes.set(key, h);
    if (lastPushed.get(key) === h) continue;

    const parts = splitChunks(json);
    parts.forEach((chunk, i) => {
      ops.push({
        replaceOne: {
          filter: { _id: `${key}::${i}` },
          replacement: { key, part: i, parts: parts.length, json: chunk, updatedAt: new Date() },
          upsert: true,
        },
      });
    });
    // احذف أجزاء قديمة زادت (لو القسم صار أصغر)
    ops.push({ deleteMany: { filter: { key, part: { $gte: parts.length } } } });
  }

  // أقسام اتحذفت محليًا
  for (const key of lastPushed.keys()) {
    if (!newHashes.has(key)) ops.push({ deleteMany: { filter: { key } } });
  }

  if (ops.length === 0) return true;
  await coll.bulkWrite(ops as any, { ordered: true });
  lastPushed.clear();
  for (const [k, v] of newHashes) lastPushed.set(k, v);
  return true;
}

async function runPush(): Promise<void> {
  if (pushing) {
    dirtyWhilePushing = true;
    return;
  }
  pushing = (async () => {
    try {
      await pushNow();
    } catch (err: any) {
      logger.warn(`⚠️ فشل رفع البيانات لـ MongoDB (البيانات المحلية سليمة): ${err?.message || err}`);
    } finally {
      pushing = null;
      if (dirtyWhilePushing) {
        dirtyWhilePushing = false;
        scheduleMongoSync();
      }
    }
  })();
  await pushing;
}

/** يُستدعى مع كل كتابة محلية — يجدول رفعًا مؤجلًا (لا يبطئ الحفظ المحلي). */
export function scheduleMongoSync(): void {
  if (!ready || !isMongoConfigured()) return;
  if (pushTimer) return;
  pushTimer = setTimeout(() => {
    pushTimer = null;
    void runPush();
  }, PUSH_DELAY_MS);
  pushTimer.unref?.();
}

/** رفع فوري (عند الإيقاف) مع مهلة قصوى حتى لا نعلّق الإغلاق. */
export async function flushMongoSync(timeoutMs = 5000): Promise<void> {
  if (!ready || !isMongoConfigured()) return;
  if (pushTimer) {
    clearTimeout(pushTimer);
    pushTimer = null;
  }
  try {
    await Promise.race([
      (async () => {
        if (pushing) await pushing;
        await pushNow();
      })(),
      new Promise((resolve) => setTimeout(resolve, timeoutMs)),
    ]);
  } catch (err: any) {
    logger.warn(`⚠️ تعذّر الرفع الأخير قبل الإيقاف: ${err?.message || err}`);
  }
}

export interface RemoteState {
  reachable: boolean;
  data: Record<string, unknown> | null; // null = لا يوجد شيء مخزن
}

/** يقرأ كل الأقسام من MongoDB ويركّبها. reachable=false لو ما قدرنا نتصل. */
export async function fetchMongoState(): Promise<RemoteState> {
  if (!isMongoConfigured()) return { reachable: false, data: null };
  try {
    const coll = await getColl();
    if (!coll) return { reachable: false, data: null };
    const docs = await coll.find({}).toArray();
    if (docs.length === 0) return { reachable: true, data: null };

    const byKey = new Map<string, StateDoc[]>();
    for (const d of docs) {
      if (!byKey.has(d.key)) byKey.set(d.key, []);
      byKey.get(d.key)!.push(d);
    }
    const result: Record<string, unknown> = {};
    for (const [key, parts] of byKey) {
      parts.sort((a, b) => a.part - b.part);
      if (parts.length !== parts[0].parts) {
        logger.warn(`⚠️ القسم "${key}" في MongoDB ناقص أجزاء — تم تجاهله.`);
        continue;
      }
      try {
        result[key] = JSON.parse(parts.map((p) => p.json).join(""));
        lastPushed.set(key, md5(parts.map((p) => p.json).join("")));
      } catch {
        logger.warn(`⚠️ القسم "${key}" في MongoDB تالف — تم تجاهله.`);
      }
    }
    return { reachable: true, data: Object.keys(result).length ? result : null };
  } catch (err: any) {
    logger.warn(`⚠️ تعذّر جلب البيانات من MongoDB عند الإقلاع: ${err?.message || err}`);
    return { reachable: false, data: null };
  }
}

/** رفع كامل فوري (ترحيل أول مرة من الملف المحلي). */
export async function pushAllNow(): Promise<boolean> {
  try {
    lastPushed.clear();
    return await pushNow();
  } catch (err: any) {
    logger.warn(`⚠️ فشل الرفع الأولي لـ MongoDB: ${err?.message || err}`);
    return false;
  }
}
