/**
 * 🏷️ نظام الألقاب (.تسجيل_لقب / .حجز_لقب / .اللقاب ...) على MongoDB.
 *
 * مجموعة "titles": كل مستند { userId, title, updatedAt } مع فهرسين فريدين:
 *  - userId فريد (لقب واحد لكل شخص)
 *  - title فريد (اللقب ما يتكرر — طلب قديم "ما أبيها تتكرر")
 * أخطاء التكرار ترجع بـ code = 11000 مثل ما كانت تتوقع ملفات الأوامر.
 *
 * الواجهة (findOne/findOneAndUpdate/findOneAndDelete/find/deleteMany) نفس
 * الشكل القديم تمامًا، فملفات الأوامر ما تحتاج أي تعديل غير مسار الاستيراد.
 */
import { Collection } from "mongodb";
import { getMongoDb, isMongoConfigured } from "./mongoClient";
import { logger } from "../utils/logger";
import fs from "fs";
import path from "path";

/**
 * 🆕 تخزين محلي للألقاب (database/titles.json) يُستخدم تلقائيًا لما MONGODB_URI ما يكون مضبوط —
 * هذا كان سبب "أمر الألقاب مش شغال" (كل أوامر الألقاب ترد "نظام الألقاب غير متصل" بدون MongoDB).
 * نفس القواعد: لقب واحد لكل شخص، واللقب ما يتكرر (يرمي خطأ code 11000).
 */
const LOCAL_FILE = path.resolve(process.cwd(), "database", "titles.json");
let localRows: TitleRow[] | null = null;
let saveTimer: NodeJS.Timeout | null = null;

function loadLocal(): TitleRow[] {
  if (localRows) return localRows;
  try {
    const raw = JSON.parse(fs.readFileSync(LOCAL_FILE, "utf-8"));
    localRows = (Array.isArray(raw) ? raw : []).map((r: any) => ({ userId: String(r.userId), title: String(r.title), updatedAt: new Date(r.updatedAt || Date.now()) }));
  } catch {
    localRows = [];
  }
  return localRows;
}
function saveLocal(): void {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      fs.mkdirSync(path.dirname(LOCAL_FILE), { recursive: true });
      fs.writeFileSync(LOCAL_FILE, JSON.stringify(loadLocal()), "utf-8");
    } catch (err) {
      logger.warn("⚠️ تعذر حفظ ملف الألقاب المحلي:", err);
    }
  }, 500);
}
const localMode = () => !isMongoConfigured();
function localDoc(row: TitleRow | undefined): TitleDoc | null {
  if (!row) return null;
  const doc: TitleDoc = {
    userId: row.userId,
    title: row.title,
    async save() {
      const r = loadLocal().find((x) => x.userId === doc.userId);
      if (r) {
        r.title = doc.title;
        r.updatedAt = new Date();
        saveLocal();
      }
    },
  };
  return doc;
}


interface TitleRow {
  userId: string;
  title: string;
  updatedAt: Date;
}

export interface TitleDoc {
  userId: string;
  title: string;
  /** يحدّث اللقب لنفس userId (يستخدمها .تغير_لقب بعد تعديل .title مباشرة). */
  save(): Promise<void>;
}

let indexesReady = false;

async function getColl(): Promise<Collection<TitleRow> | null> {
  const db = await getMongoDb();
  return db ? db.collection<TitleRow>("titles") : null;
}

function toDoc(row: TitleRow | null): TitleDoc | null {
  if (!row) return null;
  const doc: TitleDoc = {
    userId: row.userId,
    title: row.title,
    async save() {
      const coll = await getColl();
      if (!coll) throw new Error("MongoDB غير متصل");
      await coll.updateOne({ userId: doc.userId }, { $set: { title: doc.title, updatedAt: new Date() } });
    },
  };
  return doc;
}

/** يتأكد إن MongoDB متصل وإن الفهارس موجودة. */
export async function ensureTitlesReady(): Promise<boolean> {
  if (localMode()) return true; // تخزين محلي
  const coll = await getColl();
  if (!coll) return false;
  if (!indexesReady) {
    try {
      await coll.createIndex({ userId: 1 }, { unique: true });
      await coll.createIndex({ title: 1 }, { unique: true });
      indexesReady = true;
    } catch (err: any) {
      // لو فيه بيانات مكررة قديمة قد يفشل الفهرس — نكمل بدونه بدل ما نوقف النظام
      logger.warn(`⚠️ تعذّر إنشاء فهارس الألقاب: ${err?.message || err}`);
      indexesReady = true;
    }
  }
  return true;
}

export const TitleStore = {
  async findOne(query: { userId?: string; title?: string }): Promise<TitleDoc | null> {
    if (localMode()) return localDoc(loadLocal().find((r) => (query.userId ? r.userId === query.userId : true) && (query.title ? r.title === query.title : true)));
    const coll = await getColl();
    if (!coll) return null;
    const filter: Record<string, string> = {};
    if (query.userId) filter.userId = query.userId;
    if (query.title) filter.title = query.title;
    try {
      return toDoc(await coll.findOne(filter));
    } catch (err: any) {
      logger.warn(`⚠️ خطأ أثناء قراءة لقب: ${err?.message || err}`);
      return null;
    }
  },

  async findOneAndUpdate(
    filter: { userId: string },
    update: { title: string },
    _opts?: { upsert?: boolean }
  ): Promise<TitleDoc | null> {
    if (localMode()) {
      const rows = loadLocal();
      if (rows.some((r) => r.title === update.title && r.userId !== filter.userId)) {
        const e: any = new Error("DUPLICATE_TITLE");
        e.code = 11000;
        throw e;
      }
      let row = rows.find((r) => r.userId === filter.userId);
      if (row) {
        row.title = update.title;
        row.updatedAt = new Date();
      } else {
        row = { userId: filter.userId, title: update.title, updatedAt: new Date() };
        rows.push(row);
      }
      saveLocal();
      return localDoc(row);
    }
    const coll = await getColl();
    if (!coll) return null;
    // يرمي خطأ code 11000 لو اللقب محجوز لشخص ثاني
    const res = await coll.findOneAndUpdate(
      { userId: filter.userId },
      { $set: { title: update.title, updatedAt: new Date() } },
      { upsert: true, returnDocument: "after" }
    );
    return toDoc(res);
  },

  async findOneAndDelete(query: { userId?: string; title?: string }): Promise<TitleDoc | null> {
    if (localMode()) {
      const rows = loadLocal();
      const i = rows.findIndex((r) => (query.userId ? r.userId === query.userId : true) && (query.title ? r.title === query.title : true));
      if (i < 0) return null;
      const [removed] = rows.splice(i, 1);
      saveLocal();
      return localDoc(removed);
    }
    const coll = await getColl();
    if (!coll) return null;
    const filter: Record<string, string> = {};
    if (query.userId) filter.userId = query.userId;
    if (query.title) filter.title = query.title;
    try {
      return toDoc(await coll.findOneAndDelete(filter));
    } catch (err: any) {
      logger.warn(`⚠️ خطأ أثناء حذف لقب: ${err?.message || err}`);
      return null;
    }
  },

  async find(_query: Record<string, never> = {}): Promise<TitleDoc[]> {
    if (localMode()) return [...loadLocal()].sort((a, b) => a.title.localeCompare(b.title, "ar")).map((r) => localDoc(r)!);
    const coll = await getColl();
    if (!coll) return [];
    try {
      const rows = await coll.find({}).sort({ title: 1 }).toArray();
      return rows.map((r) => toDoc(r)!).filter(Boolean);
    } catch (err: any) {
      logger.warn(`⚠️ خطأ أثناء جلب كل الألقاب: ${err?.message || err}`);
      return [];
    }
  },

  async deleteMany(_query: Record<string, never> = {}): Promise<{ deletedCount: number }> {
    if (localMode()) {
      const n = loadLocal().length;
      localRows = [];
      saveLocal();
      return { deletedCount: n };
    }
    const coll = await getColl();
    if (!coll) return { deletedCount: 0 };
    try {
      const r = await coll.deleteMany({});
      return { deletedCount: r.deletedCount || 0 };
    } catch (err: any) {
      logger.warn(`⚠️ خطأ أثناء حذف كل الألقاب: ${err?.message || err}`);
      return { deletedCount: 0 };
    }
  },
};
