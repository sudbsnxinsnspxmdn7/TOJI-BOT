import { WASocket } from "@whiskeysockets/baileys";
import { isOwner } from "../middlewares/permissions";
import { logger } from "../utils/logger";
import { CONFIG } from "../config/config";
import { getFriendCfg } from "../utils/friendUtils";

/**
 * 🆕 (طلب صريح: "إذا طلب المطور الانضمام لإحدى هذه المجموعات، وكان
 * البوت أدمن وقادر، يقبل الطلب فورًا") — يسجّل مستمع لطلبات الانضمام
 * (لما تكون المجموعة بوضع "موافقة الأدمن على الأعضاء الجدد" مفعّلة)،
 * ويوافق تلقائيًا فقط لو الطالب هو مطور *هذا البوت بالذات* (رئيسي أو
 * فرعي، عبر isOwner مع sock — نفس مفهوم "مطور منعزل لبوته" المستخدم
 * بكل المشروع).
 *
 * ⚠️ صراحة تامة: حدث "group.join-request" وAPI الموافقة
 * (groupRequestParticipantsUpdate) موجودان بتوثيق Baileys للنسخة
 * المثبتة بهذا المشروع (^6.7.23)، لكن ما قدرت أختبر هذا فعليًا (بيئة
 * الكتابة بلا اتصال إنترنت، ولا حساب واتساب حقيقي متاح). لو ما اشتغل،
 * أرسل لي رسالة الخطأ اللي تظهر بالسجل (logger.error هنا) بالضبط.
 */
export function registerJoinRequestAutoApprove(sock: WASocket) {
  const ev = sock.ev as unknown as {
    on: (event: string, cb: (update: any) => void) => void;
  };

  try {
    ev.on("group.join-request", async (update: any) => {
      try {
        // شكل الحدث يختلف بين نسخ Baileys — نحاول أكثر من صيغة شائعة
        const groupId: string | undefined = update?.id || update?.groupId || update?.chatId;
        const participant: string | undefined =
          update?.participant || update?.author || update?.jid;
        if (!groupId || !participant) return;
        // 🆕 واتساب الحديث يرسل أحيانًا المعرّف بصيغة @lid، ورقم الهاتف الحقيقي
        // بحقل منفصل (participantPn / authorPn) — نفحص كل الصيغ حتى ما يضيع قبول المطور.
        const candidates: string[] = [participant, update?.participantPn, update?.authorPn, update?.phoneNumber]
          .filter((x: any) => typeof x === "string" && x);
        if (update?.action && update.action !== "created" && update.action !== "request") {
          // رفض/سحب طلب — ما نتدخل
          if (update.action === "rejected" || update.action === "revoked") return;
        }

        // 🆕 (طلب صريح: "يقبل رقمي دائمًا حتى لو بوت فرعي") — رقم المطور (الأساسي/
        // الثاني/الثالث من .env) يُقبل فورًا بأي بوت (رئيسي أو فرعي) هو أدمن بالجروب.
        const ownerNumbers = [CONFIG.OWNER_NUMBER, CONFIG.OWNER_NUMBER_2, CONFIG.OWNER_NUMBER_3]
          .filter(Boolean)
          .map((n) => String(n).replace(/\D/g, ""));
        const isOwnerRequest = candidates.some(
          (c) => ownerNumbers.includes(c.split("@")[0].split(":")[0].replace(/\D/g, "")) || isOwner(c, undefined, sock)
        );

        if (!isOwnerRequest) {
          // 🆕 (.طلبات تلقائي تشغيل) قبول تلقائي لكل طلب بهذي المجموعة
          if (getFriendCfg(groupId).autoAccept) {
            await sock.groupRequestParticipantsUpdate(groupId, [participant], "approve");
          }
          return;
        }

        await sock.groupRequestParticipantsUpdate(groupId, [participant], "approve");
        logger.info(`✅ تم قبول طلب انضمام المطور تلقائيًا بالمجموعة ${groupId}`);
      } catch (err) {
        logger.error("فشل قبول طلب انضمام تلقائي (راجع تعليق الملف — قد تختلف صيغة الحدث):", err);
      }
    });
  } catch (err) {
    logger.warn("⚠️ تعذر تسجيل مستمع طلبات الانضمام (group.join-request) — قد لا تدعمه نسخة Baileys الحالية.", err);
  }
}
