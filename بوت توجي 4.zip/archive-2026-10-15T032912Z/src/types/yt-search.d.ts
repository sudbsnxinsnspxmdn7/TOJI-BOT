declare module "yt-search" {
  const ytSearch: (query: any) => Promise<any>;
  export default ytSearch;
}
