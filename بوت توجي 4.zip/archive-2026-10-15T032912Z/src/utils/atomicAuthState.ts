/**
 * 🆕 بديل محلي 100% (بدون أي Supabase/سحابة) عن useMultiFileAuthState
 * الأصلية من Baileys — بنفس الشكل والاستخدام بالضبط (نفس المدخلات
 * والمخرجات {state, saveCreds})، الفرق الوحيد: كل كتابة ملف هنا **ذرّية**
 * (atomic): نكتب بملف مؤقت ثم نستبدله بعملية rename واحدة بدل الكتابة
 * المباشرة على الملف الأصلي.
 *
 * ⚠️ هذا بالضبط سبب "الجلسة تخرب بعد كم ساعة وتحتاج مسح QR من جديد":
 * نسخة Baileys الأصلية تكتب كل ملف (creds.json وsession-*.json وpre-key-*
 * .json...) مباشرة بـfs.writeFile. لو العملية انقطعت/قُتلت فجأة بالضبط
 * أثناء كتابة أي ملف من هذي (إعادة تشغيل من المضيف، نفاد ذاكرة، إلخ)،
 * يطلع الملف نص مكتوب = تالف. Baileys بعدها يفشل يقرأ مفاتيح التشفير
 * ويظن الجلسة انتهت، فيطلب QR من جديد رغم إن الحساب نفسه سليم تمامًا.
 *
 * بالـrename الذري: إما الملف القديم الكامل موجود، أو الجديد الكامل —
 * أبدًا نص مكتوب. فحتى لو انقطعت العملية بأسوأ توقيت ممكن، أسوأ احتمال
 * هو فقدان آخر تحديث واحد بس (مو تلف الملف بالكامل).
 */
import fs from "fs-extra";
import path from "path";
import { proto, initAuthCreds, BufferJSON } from "@whiskeysockets/baileys";

function keyFileName(key: string): string {
  return `${key.replace(/\//g, "__")}.json`;
}

let tempFileSequence = 0;
const fileWriteQueues = new Map<string, Promise<void>>();

async function atomicWriteJSON(filePath: string, data: unknown): Promise<void> {
  // تسلسل الكتابات لنفس الملف يمنع تحديثًا أقدم من أن يطغى على تحديث أحدث،
  // ومع رقم فريد نتجنب تصادم أسماء الملفات المؤقتة عند تحديثات متقاربة جدًا.
  const previous = fileWriteQueues.get(filePath) ?? Promise.resolve();
  const write = previous.catch(() => undefined).then(async () => {
    const dir = path.dirname(filePath);
    const tmpPath = path.join(dir, `.tmp-${path.basename(filePath)}-${process.pid}-${Date.now()}-${++tempFileSequence}`);
    try {
      await fs.writeFile(tmpPath, JSON.stringify(data, BufferJSON.replacer));
      await fs.rename(tmpPath, filePath);
    } finally {
      await fs.remove(tmpPath).catch(() => undefined);
    }
  });
  fileWriteQueues.set(filePath, write);
  try {
    await write;
  } finally {
    if (fileWriteQueues.get(filePath) === write) fileWriteQueues.delete(filePath);
  }
}

async function readJSONIfExists(filePath: string): Promise<any | null> {
  try {
    const raw = await fs.readFile(filePath, { encoding: "utf-8" });
    return JSON.parse(raw, BufferJSON.reviver);
  } catch {
    return null;
  }
}

/** ينظّف أي ملف مؤقت يتيم خلّفته عملية انقطعت بالضبط بين الكتابة والـrename
 * (احتمال نادر جدًا، ولا يضر شي لو تراكم، بس تنظيفه عند كل إقلاع أنضف). */
async function cleanupOrphanedTempFiles(folder: string): Promise<void> {
  try {
    const names = await fs.readdir(folder);
    await Promise.all(
      names.filter((n) => n.startsWith(".tmp-")).map((n) => fs.remove(path.join(folder, n)).catch(() => {}))
    );
  } catch {
    // المجلد غير موجود بعد — طبيعي بأول تشغيل
  }
}

/**
 * بديل ذرّي لـ useMultiFileAuthState — نفس التوقيع والسلوك بالضبط، فقط
 * الكتابة الفعلية على القرص صارت آمنة من التلف الجزئي.
 */
export async function useMultiFileAuthStateAtomic(
  folder: string
): Promise<{ state: { creds: any; keys: any }; saveCreds: () => Promise<void> }> {
  await fs.ensureDir(folder);
  await cleanupOrphanedTempFiles(folder);

  const credsPath = path.join(folder, "creds.json");
  const creds = (await readJSONIfExists(credsPath)) || initAuthCreds();

  return {
    state: {
      creds,
      keys: {
        get: async (type: string, ids: string[]) => {
          const data: Record<string, any> = {};
          await Promise.all(
            ids.map(async (id) => {
              let value = await readJSONIfExists(path.join(folder, keyFileName(`${type}-${id}`)));
              if (type === "app-state-sync-key" && value) {
                value = proto.Message.AppStateSyncKeyData.fromObject(value);
              }
              data[id] = value;
            })
          );
          return data;
        },
        set: async (data: Record<string, Record<string, any>>) => {
          const tasks: Promise<void>[] = [];
          for (const category of Object.keys(data)) {
            for (const id of Object.keys(data[category])) {
              const value = data[category][id];
              const filePath = path.join(folder, keyFileName(`${category}-${id}`));
              tasks.push(
                value
                  ? atomicWriteJSON(filePath, value)
                  : fs.remove(filePath).catch(() => {
                      /* أصلًا غير موجود — عادي */
                    })
              );
            }
          }
          await Promise.all(tasks);
        },
      },
    },
    saveCreds: () => atomicWriteJSON(credsPath, creds),
  };
}
