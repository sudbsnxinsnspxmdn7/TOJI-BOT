import { WASocket, WAMessage } from "@whiskeysockets/baileys";
import { formatDateTime, jidToMention } from "./helpers";

/**
 * قوالب رسائل البوت الموحّدة (بإطار البوت الجديد). ⚠️ النصوص هنا أسطر ثابتة بدون
 * أي فواصل أسطر إضافية داخل السطر الواحد — حتى لا ينكسر الخط/الزخرفة بواتساب.
 */
const HEAD = "『 𝑩𝑶𝑶𝑫𝒀┆ 🌑 ┆𝑩𝑶𝑻 』";
const LINE = "ـ⌬┪─━─┢🩸┪─━─┢⌬";
const FOOT_TOP = "ـ⌬┒━─━┈┉┈━─━─┎";
const FOOT_BOT = "ـ⌬┙━─━┈┉┈━─━─┖";

/** يحوّل أي نص لسطر واحد (بدون إنتر) حتى ما يخرب الإطار */
function oneLine(text: unknown, max = 200): string {
  const s = String(text ?? "").replace(/\s+/g, " ").trim();
  return s.length > max ? s.slice(0, max - 1) + "…" : s;
}

export function packProgressText(senderJid: string, query: string, groupName: string, count = 30): string {
  return [
    HEAD,
    LINE,
    `ـ⌬┋ _*جاري تجميع ${count} ملصق*_`,
    "ـ⌬┋ _*المستخدم:↓*_",
    `ـ⌬┋ _*${jidToMention(senderJid)}*_`,
    "ـ⌬┋ _*الطلب:↓*_ ",
    `ـ⌬┋ *_${oneLine(query, 60)}_*`,
    LINE,
    `ـ⌬┋ ${oneLine(groupName, 60)} `,
    FOOT_TOP,
    "ـ⌬│ 𝑩𝑶𝑶𝑫𝒀 𝑩𝑶𝑻 ",
    FOOT_BOT,
  ].join("\n");
}

const phoneOf = (jid: string) => jid.split("@")[0].split(":")[0];

/** رسالة "جاري البحث عن تصاميم" لأمر .ايديت */
export function editSearchingText(number: number | string, query: string, groupName: string): string {
  return [
    HEAD,
    `┪─━─┢⌬┋☽${number} ☾┋⌬┪─━─┢`,
    "ـ⌬┋ _*جاري البحث عن تصاميم*_",
    "ـ⌬┋ *_الطلب:↓_*",
    `ـ⌬┋ _*${oneLine(query, 60)}*_`,
    "ـ⌬┪─━─┢🐱┪─━─┢⌬",
    `ـ⌬┋ ${oneLine(groupName, 60)} `,
    FOOT_TOP,
    "ـ⌬│ قسم الأدوات   ",
    FOOT_BOT,
  ].join("\n");
}

/** رسالة "تم ايجاد N فيديوهات" لأمر .ايديت (تُرسل كنص أعلى الكاروسيل) */
export function editFoundText(number: number | string, count: number, query: string, groupName: string): string {
  return [
    HEAD,
    `┪─━─┋☽${number} ☾┋─━─┢`,
    `ـ⌬┋ _*تم ايجاد ${count} فيديوهات*_`,
    "ـ⌬┋ *_الطلب:↓_*",
    `ـ⌬┋ *_${oneLine(query, 60)}_*`,
    "ـ⌬┪─━─┢🐱┪─━─┢⌬",
    `ـ⌬┋ ${oneLine(groupName, 60)}`,
  ].join("\n");
}

/** نص قائمة الأوامر الجانبية (القالب الجديد) */
export function sideMenuText(groupName: string): string {
  return [
    HEAD,
    FOOT_TOP,
    "ـ⌬│☽ *_الوامر الجانبيه_*☾┋⌬",
    FOOT_BOT,
    "ـ⌬┋ *_هذا الوامر هي اوامر_*",
    "ـ⌬┋ *_لم يتم اتاكد من انها_*",
    "ـ⌬┋ *_تعمل بلكامل دون_*",
    "ـ⌬┋ _*اخطاء يمكنك التجربه*_",
    "ـ⌬┪─━─┢🌷┪─━─┢⌬",
    `ـ⌬┋ ${oneLine(groupName, 60)} `,
    "ـ⌬┪─━─┢🌷┪─━─┢⌬",
  ].join("\n");
}

export function packDoneText(senderJid: string, query: string, groupName: string, count = 30): string {
  return [
    HEAD,
    LINE,
    `ـ⌬┋تم تجميع ${count} ملصق لى↓`,
    `ـ⌬┋ ${oneLine(query, 60)} `,
    "ـ⌬┋ *الملكيه ↓*",
    `ـ⌬┋ *${jidToMention(senderJid)}*`,
    `ـ⌬┋ ـ ${formatDateTime().time} ـ `,
    LINE,
    `ـ⌬┋ ${oneLine(groupName, 60)} `,
    FOOT_TOP,
    "ـ⌬│ 𝑩𝑶𝑶𝑫𝒀 𝑩𝑶𝑻   ┃",
    FOOT_BOT,
  ].join("\n");
}

export function errorText(senderJid: string, error: unknown, groupName: string): string {
  const reason = oneLine((error as any)?.message ?? error, 160);
  return [
    HEAD,
    "ـ⌬┪─━─┢🩸┪─━─┢⌬ ",
    "ـ⌬┋ *اسف يا*",
    `ـ⌬┋ *${jidToMention(senderJid)}*`,
    "ـ⌬┋ *هناك خطا ما*",
    "ـ⌬┋ *ارسل هذا الا المطور*",
    "ـ⌬┋ *الخطا:* ↓",
    `> ${reason} `,
    LINE,
    `ـ⌬┋ ${oneLine(groupName, 60)} `,
    FOOT_TOP,
    "ـ⌬│ 𝑩𝑶𝑶𝑫𝒀 𝑩𝑶𝑻   ┃",
    FOOT_BOT,
  ].join("\n");
}

/** يرسل رسالة الخطأ الموحدة (بدل رسائل الخطأ القديمة) */
export async function sendErrorMessage(
  sock: WASocket,
  chatId: string,
  senderJid: string,
  error: unknown,
  groupName: string,
  quoted?: WAMessage
): Promise<void> {
  try {
    await sock.sendMessage(
      chatId,
      { text: errorText(senderJid, error, groupName), mentions: [senderJid] },
      quoted ? { quoted } : undefined
    );
  } catch {
    /* حتى لو فشل إرسال رسالة الخطأ ما نكسر شي */
  }
}

/** رسالة "لديك يوزر نيم ولم نتعرف على رقمك" لأمر .تنصيب (القالب الجديد) */
export function installNeedNumberText(prefix: string, groupName: string): string {
  return [
    HEAD,
    "ـ⌬┪─━─┢🎪┪─━─┢⌬",
    "ـ⌬┋ *_انت لديك يوزر نيم_*",
    "ـ⌬┋ *_ولم نصططع اتعرف علا_*",
    "ـ⌬┋ _*رقمك*_",
    "ـ⌬┋  _*اكتب رقمك يدويًا بهذي*_ ",
    "ـ⌬┋ _*الصيغة:*_",
    `ـ⌬┋ ${prefix}تنصيب <رقمك>`,
    "ـ⌬┋ مثال:",
    `ـ⌬┋ \`${prefix}تنصيب +44 7453 388374\``,
    "ـ⌬┪─━─┢⏳┪─━─┢⌬",
    `ـ⌬┋  ${oneLine(groupName, 60)} `,
    FOOT_TOP,
    "ـ⌬│ قسم التنصيب   ┃",
    FOOT_BOT,
  ].join("\n");
}
