/**
 * 🎨 تنسيق نصوص أزرار البوت (طلب صريح من المطور):
 *  • حذف أي إيموجي من الأزرار.
 *  • القالب العام:  ⌬┋☽<النص>☾┋⌬
 *  • كل كلمة فيها أكثر من حرفين عربيين: نضيف "ـ" (تطويل) بين الحرفين المتصلين فقط،
 *    وتُحذف من أول الكلمة وآخرها، ولا تُوضع بعد حرف لا يتصل بما بعده
 *    (ا أ إ آ د ذ ر ز و ؤ ء ة ى) — مثال: "الغاء" → "الـغـاء"، "كروب" → "كـروب".
 *  • كلمات من حرف أو حرفين تبقى كما هي.
 *  • أزرار لها صيغة جاهزة محددة (التنصيب/الأقسام/رجوع/نسخ الكود/القناة) تُستبدل بصيغتها.
 *
 * الدالة idempotent: لو النص مُنسّق مسبقًا (يبدأ بـ ⌬) يرجع كما هو.
 */
const NON_JOINING_NEXT = new Set("اأإآٱدذرزوؤءةى".split(""));
const ARABIC_LETTER = /[\u0621-\u064A\u0671]/;
const HARAKAT = /[\u064B-\u065F\u0670]/g;

const PRESETS = {
  group: "⌬┋☽كـروب الـتـنـصـيـب☾┋⌬",
  start: "⌬┋☽ابـدا الـتـنـصـيـب☾┋⌬",
  cancel: "⌬┋☽الـغـاء الـتـنـصـيـب☾┋⌬",
  copy: "⌬┋↱ 𝑪𝑶𝑷𝒀 𝑪𝑶𝑫𝑬 ↲┋⌬",
  back: "⌬┋↱ رجــــــــــوع┋⌬",
  sections: "⌬ ≡ الاقــــــســــــام┋⌬",
  channel: "⌬┋↲ ق̶ــن̶ــا̶ت̶ ا̶ل̶ــــب̶ـو̶ت̶↱ ┋⌬",
} as const;

function stripEmoji(s: string): string {
  return s
    .replace(/[\p{Extended_Pictographic}\uFE0F\u200D\u20E3]/gu, "")
    .replace(/[\u200e\u200f\u202a-\u202e]/g, "")
    .replace(/[^\p{L}\p{N}\p{M}\s.\-:/()]/gu, "");
}

function normalizeForMatch(s: string): string {
  return stripEmoji(s)
    .replace(/ـ/g, "")
    .replace(HARAKAT, "")
    .replace(/[أإآٱ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/\s+/g, " ")
    .trim();
}

function tatweelWord(word: string): string {
  const letters = Array.from(word);
  const arabicCount = letters.filter((c) => ARABIC_LETTER.test(c)).length;
  if (arabicCount < 3) return word;
  let out = "";
  for (let i = 0; i < letters.length; i++) {
    out += letters[i];
    const cur = letters[i];
    const next = letters[i + 1];
    if (next && ARABIC_LETTER.test(cur) && ARABIC_LETTER.test(next) && !NON_JOINING_NEXT.has(cur)) {
      out += "ـ";
    }
  }
  return out;
}

export function styleButtonLabel(label: string): string {
  const raw = String(label ?? "").trim();
  if (!raw || raw.startsWith("⌬")) return raw;

  const n = normalizeForMatch(raw);
  if (n.includes("تنصيب")) {
    if (n.includes("الغاء")) return PRESETS.cancel;
    if (n.includes("ابدا") || n.includes("الان") || n.includes("ابدأ")) return PRESETS.start;
    return PRESETS.group; // "التنصيب" / "كروب التنصيب" = زر كروب التنصيب
  }
  if (n.includes("نسخ") && n.includes("كود")) return PRESETS.copy;
  if (n.includes("القائمه الرئيسيه") || n.includes("القائمة الرئيسية") || n.includes("العوده") || n === "رجوع") return PRESETS.back;
  if (n === "الاقسام" || n === "اقسام") return PRESETS.sections;
  if (n.includes("قناة") || n.includes("قناه") || n.includes("القناة") || n.includes("القناه")) return PRESETS.channel;

  const cleaned = stripEmoji(raw).replace(/ـ/g, "").replace(/\s+/g, " ").trim();
  if (!cleaned) return raw;
  const styled = cleaned.split(" ").map(tatweelWord).join(" ");
  return `⌬┋☽${styled}☾┋⌬`;
}

/** يطبّق التنسيق على زر nativeFlow خام (quick_reply / cta_url / cta_copy / single_select) */
export function styleFlowButton<T extends { name: string; buttonParamsJson: string }>(btn: T): T {
  try {
    const params = JSON.parse(btn.buttonParamsJson);
    if (typeof params.display_text === "string") params.display_text = styleButtonLabel(params.display_text);
    if (btn.name === "single_select" && typeof params.title === "string") params.title = styleButtonLabel(params.title);
    return { ...btn, buttonParamsJson: JSON.stringify(params) };
  } catch {
    return btn;
  }
}
