import {
  WASocket,
  WAMessage,
  proto,
  generateWAMessageFromContent,
  generateWAMessageContent,
} from "@whiskeysockets/baileys";
import { CONFIG } from "../config/config";
import { logger } from "./logger";
import { buildNewsletterForwardContext } from "./interactive";
import { styleButtonLabel, styleFlowButton } from "./buttonStyle";

/**
 * ============================================================================
 * 🎠 كاروسيل واتساب (بطاقات تتحرك يمين/يسار بالإصبع) — نفس شكل بوت الصديق
 * ============================================================================
 * كل بطاقة = ميديا بالرأس (صورة أو فيديو) + نص + فوتر + أزرار (cta_url أو
 * quick_reply). الرسالة الأم فيها النص العلوي ("اسحب لرؤية باقي النتائج").
 *
 * يعتمد على proto.Message.InteractiveMessage.CarouselMessage الموجودة أصلًا
 * بمكتبة Baileys الحالية (تحققت من وجودها بالـ d.ts) — بدون أي حزمة إضافية.
 *
 * ⚠️ صراحة: واتساب لا يضمن عرض الكاروسيل لكل أنواع الحسابات/الإصدارات. لو
 * فشل الإرسال (استثناء)، نرجع تلقائيًا لإرسال النتائج كرسائل عادية متتالية
 * (نفس الميديا + النص) حتى لا يضيع أي أمر.
 * ============================================================================
 */

export interface CarouselButton {
  /** "url" يفتح رابط، "reply" يرسل نص الزر كرسالة (تُطابَق كأمر عبر matchButtonTrigger) */
  type: "url" | "reply" | "copy" | "raw";
  label: string;
  /** للرابط: الـURL — للنسخ: النص المنسوخ — للرد: المعرّف الداخلي (اختياري) */
  value?: string;
  /** للنوع "raw": زر nativeFlow جاهز (مثل single_select) يمرَّر كما هو */
  raw?: { name: string; buttonParamsJson: string };
}

export interface CarouselCard {
  image?: Buffer;
  video?: Buffer;
  /** true = الفيديو يتحرك كـGIF (نفس الإعداد المجرّب بقائمة البوت) */
  gif?: boolean;
  /** نص البطاقة (العنوان/الحقول) */
  body: string;
  footer?: string;
  buttons?: CarouselButton[];
}

export interface CarouselOptions {
  /** النص العلوي بالرسالة الأم */
  text: string;
  footer?: string;
  cards: CarouselCard[];
  quoted?: WAMessage;
  mentions?: string[];
  /**
   * "messages" (الافتراضي): لو فشل الكاروسيل نرسل كل بطاقة كرسالة عادية.
   * "throw": نرمي الخطأ ليتصرف المستدعي (مثلاً يرجع للقائمة القديمة بزر الاختيار).
   */
  onFail?: "messages" | "throw";
}

function buildCardButtons(buttons: CarouselButton[] | undefined) {
  const list = (buttons && buttons.length ? buttons : defaultButtons()).slice(0, 3);
  return list.map((b) => styleFlowButton(buildOne(b)));
}

function buildOne(b: CarouselButton) {
  {
    if (b.type === "raw" && b.raw) return b.raw;
    if (b.type === "url" && b.value) {
      return {
        name: "cta_url",
        buttonParamsJson: JSON.stringify({ display_text: b.label, url: b.value, merchant_url: b.value }),
      };
    }
    if (b.type === "copy" && b.value) {
      return {
        name: "cta_copy",
        buttonParamsJson: JSON.stringify({ display_text: b.label, id: `copy_${Date.now()}`, copy_code: b.value }),
      };
    }
    return {
      name: "quick_reply",
      buttonParamsJson: JSON.stringify({ display_text: b.label, id: b.value || `${CONFIG.PREFIX}${b.label}` }),
    };
  }
}

/** زر افتراضي بآخر كل بطاقة: "انضمام للقناة" (لو CHANNEL_LINK مضبوط) وإلا الدعم */
function defaultButtons(): CarouselButton[] {
  if (CONFIG.CHANNEL_LINK) return [{ type: "url", label: "📢 انضمام للقناة", value: CONFIG.CHANNEL_LINK }];
  if (CONFIG.SUPPORT_GROUP_LINK) return [{ type: "url", label: "🔱 الدعم", value: CONFIG.SUPPORT_GROUP_LINK }];
  return [{ type: "reply", label: "🏠 القائمة", value: `${CONFIG.PREFIX}menu` }];
}

async function buildCardHeader(sock: WASocket, card: CarouselCard): Promise<any> {
  if (card.video) {
    try {
      const content = await generateWAMessageContent(
        { video: card.video, gifPlayback: card.gif ?? false },
        { upload: sock.waUploadToServer } as any
      );
      if (content.videoMessage) {
        // 🆕 (طلب صريح: فيديو المنيو يظهر كـGIF مو فيديو عادي) — علامة GIF صريحة بالرسالة
        if (card.gif) (content.videoMessage as any).gifAttribution = 1;
        return { hasMediaAttachment: true, videoMessage: content.videoMessage };
      }
    } catch (err) {
      // نكمل لصورة البطاقة (لو موجودة) بدل ما يفشل الكاروسيل كله بسبب فيديو واحد
      logger.warn("⚠️ تعذر تجهيز فيديو بطاقة الكاروسيل:", err instanceof Error ? err.message : err);
      if (!card.image) throw err;
    }
  }
  if (card.image) {
    const content = await generateWAMessageContent({ image: card.image }, { upload: sock.waUploadToServer } as any);
    if (content.imageMessage) return { hasMediaAttachment: true, imageMessage: content.imageMessage };
  }
  return undefined;
}

function binaryNodes(chatId: string): any[] {
  const biz = {
    tag: "biz",
    attrs: {},
    content: [
      {
        tag: "interactive",
        attrs: { type: "native_flow", v: "1" },
        content: [{ tag: "native_flow", attrs: { v: "9", name: "mixed" } }],
      },
    ],
  };
  return chatId.endsWith("@g.us") ? [biz] : [biz, { tag: "bot", attrs: { biz_bot: "1" } }];
}

/**
 * يرسل كاروسيل. يرجع true لو انرسل ككاروسيل فعلي، false لو رجعنا للرسائل المتتالية.
 */
export async function sendCarousel(sock: WASocket, chatId: string, opts: CarouselOptions): Promise<boolean> {
  const usable = opts.cards.filter((c) => c.image || c.video);
  if (!usable.length) {
    await sock.sendMessage(chatId, { text: opts.text, mentions: opts.mentions } as any, opts.quoted ? { quoted: opts.quoted } : undefined);
    return false;
  }

  try {
    const cards = [];
    // نفس الـBuffer لعدة بطاقات (مثل صورة القائمة) → نرفعه مرة واحدة ونعيد استخدام الهيدر
    const headerCache = new Map<Buffer, any>();
    for (const card of usable) {
      const key = card.video || card.image!;
      let header = headerCache.get(key);
      if (!header) {
        header = await buildCardHeader(sock, card);
        if (header) headerCache.set(key, header);
      }
      if (!header) continue;
      cards.push({
        header,
        body: { text: card.body },
        footer: { text: card.footer || CONFIG.BOT_NAME.replace(/\\n|\n/g, " ") },
        nativeFlowMessage: { buttons: buildCardButtons(card.buttons) },
      });
    }
    if (!cards.length) throw new Error("NO_CARD_HEADERS");

    const fwd = buildNewsletterForwardContext();
    const content = proto.Message.fromObject({
      interactiveMessage: {
        body: opts.text && opts.text.trim() && opts.text !== "\u200e" ? { text: opts.text } : undefined, // نص علوي فاضي = بدون رسالة/فقاعة علوية
        footer: opts.footer ? { text: opts.footer } : undefined,
        carouselMessage: { cards, messageVersion: 1 },
        contextInfo:
          opts.mentions?.length || fwd
            ? { ...(opts.mentions?.length ? { mentionedJid: opts.mentions } : {}), ...(fwd || {}) }
            : undefined,
      },
    });

    const waMessage = generateWAMessageFromContent(chatId, content, {
      userJid: sock.user?.id || "",
      quoted: opts.quoted?.message ? opts.quoted : undefined,
    } as any);

    await sock.relayMessage(chatId, waMessage.message!, {
      messageId: waMessage.key.id || undefined,
      additionalNodes: binaryNodes(chatId),
    } as any);
    return true;
  } catch (err) {
    if (opts.onFail === "throw") throw err;
    logger.warn("⚠️ فشل إرسال الكاروسيل، رجوع لرسائل متتالية:", err);
    for (const card of usable) {
      try {
        const caption = `${card.body}`;
        if (card.video) await sock.sendMessage(chatId, { video: card.video, caption } as any);
        else if (card.image) await sock.sendMessage(chatId, { image: card.image, caption } as any);
      } catch (e) {
        logger.warn("⚠️ فشل إرسال بطاقة احتياطية:", e);
      }
    }
    return false;
  }
}

/** يحوّل الأرقام الإنجليزية لعربية-هندية للعناوين (① ② ...) */
export function circledNumber(n: number): string {
  const c = ["⓪", "①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧", "⑨", "⑩"];
  return c[n] ?? String(n);
}

/**
 * يبني نص بطاقة بنفس إطار الصور المرسلة (العنوان/الناشر/المصدر).
 */
export function formatCardFields(title: string, fields: Array<[string, string, string]>, index?: number): string {
  const head = index ? `──〔 ${circledNumber(index)} ${title} 〕──` : `──〔 ${title} 〕──`;
  const rows = fields.map(([emoji, name, value]) => `╭ ${emoji} ${name} :\n│ ➜ 『 ${value || "—"} 』`).join("\n│\n");
  return `${head}\n${rows}\n╰────────────`;
}
