export const COMMANDS_PER_PAGE = 20;

const CATEGORY_LABELS: Record<string, string> = {
  "بوت": "🤖 البوت",
  "مشرفين": "🛡️ المشرفون",
  "حماية": "🔐 الحماية",
  "ترفيه": "🎉 الترفيه والألعاب",
  "ادوات": "🧰 الأدوات",
  "اعدادات": "⚙️ الإعدادات",
  "السنة": "🌙 السنة",
  "المطور": "👑 المطور",
  "IA": "✨ الذكاء الاصطناعي",
  "تحليل": "🔎 التحليل",
  "العاب2D": "🕹️ ألعاب 2D",
  "تنصيب": "📲 التنصيب",
  "الراوي": "📖 الراوي",
  "اوامر_جانبيه": "➕ أوامر جانبية",
  "تعديل_الصور": "🖼️ تعديل الصور",
};

export interface DirectoryCommand {
  name: string;
  description: string;
  category: string;
  permission: "all" | "admin" | "owner";
  aliases?: string[];
}

export interface CommandDirectoryPage {
  text: string;
  page: number;
  totalPages: number;
  totalCommands: number;
}

/** يبني صفحة متجددة من سجل الأوامر الفعلي، مع وصف وصلاحية كل أمر. */
export function buildCommandDirectory(
  commands: DirectoryCommand[],
  prefix: string,
  requestedPage = 1
): CommandDirectoryPage {
  const sorted = [...commands].sort((a, b) => {
    const categoryOrder = a.category.localeCompare(b.category, "ar");
    return categoryOrder || a.name.localeCompare(b.name, "ar");
  });
  const totalPages = Math.max(1, Math.ceil(sorted.length / COMMANDS_PER_PAGE));
  const page =
    Number.isFinite(requestedPage) && requestedPage >= 1
      ? Math.min(totalPages, Math.floor(requestedPage))
      : 1;
  const start = (page - 1) * COMMANDS_PER_PAGE;
  const pageCommands = sorted.slice(start, start + COMMANDS_PER_PAGE);
  const lines = [
    "📚 *دليل أوامر البوت*",
    `الصفحة ${page} من ${totalPages} — ${sorted.length} أمر`,
    `للتنقل: ${prefix}اوامر_البوتس ${page < totalPages ? page + 1 : 1}`,
    "",
  ];

  let previousCategory = "";
  for (const command of pageCommands) {
    if (command.category !== previousCategory) {
      const label = CATEGORY_LABELS[command.category] || command.category;
      lines.push(`*${label}*`);
      previousCategory = command.category;
    }

    const aliases = (command.aliases || [])
      .filter((alias) => alias && alias !== command.name)
      .map((alias) => `${prefix}${alias}`);
    const commandLine = `${prefix}${command.name}${
      aliases.length ? ` (بدائل: ${aliases.join("، ")})` : ""
    }`;
    const permissionNote =
      command.permission === "owner"
        ? " (للمطور فقط)"
        : command.permission === "admin"
        ? " (للمشرفين)"
        : "";
    lines.push(commandLine);
    lines.push(`${command.description?.trim() || "لا يوجد وصف لهذا الأمر."}${permissionNote}`);
    lines.push("");
  }

  return {
    text: lines.join("\n").trimEnd(),
    page,
    totalPages,
    totalCommands: sorted.length,
  };
}
