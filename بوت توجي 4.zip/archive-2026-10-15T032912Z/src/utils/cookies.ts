import fs from "fs";
import os from "os";
import path from "path";
import { logger } from "./logger";

/**
 * 🍪 كوكيز يوتيوب من ملف .env مباشرة (بدون رفع ملفات ولا تحويل):
 * المتغير YTDLP_COOKIES يقبل أي صيغة من هذي:
 *   1) JSON من إضافة EditThisCookie / Cookie-Editor (Export → JSON) — الصقه بسطر واحد بين علامتي ' '
 *   2) نص cookies.txt بصيغة Netscape (الأسطر مفصولة بـ \n حرفيًا لو بسطر واحد)
 *   3) base64 لأي من الصيغتين فوق
 * البوت يحوّلها تلقائيًا ويكتبها بملف مؤقت لـyt-dlp، ويعطيها لمكتبة ytdl بصيغة JSON.
 * (يبقى YTDLP_COOKIES_FILE مدعومًا لو عندك ملف جاهز.)
 */
export interface ParsedCookies {
  netscape: string;
  list: any[];
}

function tryDecode(raw: string): string {
  const t = raw.trim();
  if (/^[A-Za-z0-9+/=\s]+$/.test(t) && t.length > 40 && !t.includes(".")) {
    try {
      const d = Buffer.from(t.replace(/\s+/g, ""), "base64").toString("utf-8");
      if (/youtube|google|# Netscape|^\s*[\[{]/i.test(d)) return d;
    } catch {
      /* مو base64 */
    }
  }
  return t;
}

export function parseCookies(rawInput: string): ParsedCookies | null {
  let raw = tryDecode(rawInput).replace(/^['"]|['"]$/g, "");
  if (!raw) return null;
  raw = raw.replace(/\\n/g, "\n").replace(/\\t/g, "\t");

  let list: any[] = [];
  if (/^\s*[\[{]/.test(raw)) {
    try {
      const j = JSON.parse(raw);
      list = Array.isArray(j) ? j : Array.isArray(j?.cookies) ? j.cookies : [];
    } catch {
      return null;
    }
  } else {
    for (const line of raw.split(/\r?\n/)) {
      if (!line.trim() || (line.startsWith("#") && !line.startsWith("#HttpOnly_"))) continue;
      const p = line.replace(/^#HttpOnly_/, "").split("\t");
      if (p.length < 7) continue;
      list.push({ domain: p[0], path: p[2], secure: p[3] === "TRUE", expirationDate: Number(p[4]) || 0, name: p[5], value: p[6].trim() });
    }
  }
  list = list.filter((c) => c && c.name && c.value !== undefined && c.domain);
  if (!list.length) return null;

  const lines = ["# Netscape HTTP Cookie File"];
  for (const c of list) {
    const domain = String(c.domain);
    const exp = Math.floor(Number(c.expirationDate ?? c.expires ?? 0)) || 0;
    lines.push([domain, domain.startsWith(".") ? "TRUE" : "FALSE", c.path || "/", c.secure ? "TRUE" : "FALSE", exp, c.name, c.value].join("\t"));
  }
  return { netscape: lines.join("\n") + "\n", list };
}

let cached: { file: string | null; parsed: ParsedCookies | null } | null = null;

export function getCookies(): { file: string | null; parsed: ParsedCookies | null } {
  if (cached) return cached;
  cached = { file: null, parsed: null };
  const raw = process.env.YTDLP_COOKIES || process.env.YT_COOKIES || "";
  if (raw.trim()) {
    const parsed = parseCookies(raw);
    if (parsed) {
      try {
        const file = path.join(os.tmpdir(), "boody-yt-cookies.txt");
        fs.writeFileSync(file, parsed.netscape, { mode: 0o600 });
        cached = { file, parsed };
        logger.success(`🍪 كوكيز يوتيوب جاهزة (${parsed.list.length} كوكي).`);
        return cached;
      } catch (err) {
        logger.warn("⚠️ تعذر كتابة ملف الكوكيز المؤقت:", err);
      }
    } else {
      logger.warn("⚠️ YTDLP_COOKIES موجود لكن صيغته غير مفهومة (استخدم JSON من الإضافة أو Netscape).");
    }
  }
  if (process.env.YTDLP_COOKIES_FILE && fs.existsSync(process.env.YTDLP_COOKIES_FILE)) {
    cached = { file: process.env.YTDLP_COOKIES_FILE, parsed: null };
  }
  return cached;
}
