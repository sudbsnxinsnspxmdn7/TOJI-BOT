import ytSearch from "yt-search";
import { tikwmSearch, downloadBuffer, downloadYouTubeBuffer } from "./downloader";
import { withTimeout } from "./timeout";
import { logger } from "./logger";
import { CONFIG } from "../config/config";
import { ytdlpDownload, ytdlpSearch, isYoutubeBlocked } from "./ytdlp";
import { ensureWhatsAppMp4 } from "./ffmpegMedia";

/**
 * يجمع حتى N فيديو تصميم/edit لكلمة معيّنة (تيك توك أولًا ثم يوتيوب) مع
 * بياناتها الحقيقية (العنوان/الناشر/المصدر) لعرضها ببطاقات الكاروسيل.
 *
 * ملاحظة: بالصورة اللي أرسلتها من البوت الثاني كان "الناشر" يظهر
 * [object Object] (خطأ عندهم). هنا نقرأ اسم الناشر كنص فعلي دائمًا.
 */
export interface EditVideo {
  title: string;
  author: string;
  source: string;
  buffer: Buffer;
  url?: string;
}

const MAX_BYTES = 12 * 1024 * 1024; // لا نرسل بطاقة فيديو أكبر من 12MB (ذاكرة الاستضافة ~350MB)
const PER_VIDEO_TIMEOUT = 40_000;

function clean(text: unknown, max = 90): string {
  const s = typeof text === "string" ? text : text == null ? "" : String((text as any).nickname ?? (text as any).name ?? "");
  const oneLine = s.replace(/\s+/g, " ").trim();
  return oneLine.length > max ? oneLine.slice(0, max - 1) + "…" : oneLine;
}

/** يشغّل مهام بتوازي محدود */
async function pool<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R | null>, want: number): Promise<R[]> {
  const out: R[] = [];
  let i = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (i < items.length && out.length < want) {
      const item = items[i++];
      try {
        const r = await fn(item);
        if (r && out.length < want) out.push(r);
      } catch (err) {
        logger.warn("⚠️ فشل تجهيز فيديو بطاقة:", err instanceof Error ? err.message : err);
      }
    }
  });
  await Promise.all(workers);
  return out;
}

let tikwmDownUntil = 0; // لو tikwm رجّع 401/غير متاح نتخطاه 10 دقايق بدل ما نضيّع وقت المستخدم

async function fromTikTok(query: string, want: number): Promise<EditVideo[]> {
  if (Date.now() < tikwmDownUntil) return [];
  const normalized = query.replace(/[\u064B-\u065F\u0670]/g, "").trim().replace(/\s+/g, " ");
  let list = await tikwmSearch(`${normalized} edit`).catch(() => [] as any[]);
  if (!list.length) list = await tikwmSearch(normalized);
  if (!list.length && normalized.includes(" ")) list = await tikwmSearch(normalized.split(" ")[0]);
  // نخلط قليلًا حتى لا تتكرر نفس النتائج بكل بحث، ونستبعد الطويل (>3 دقائق)
  const candidates = list
    .filter((v: any) => (v?.play || v?.hdplay || v?.wmplay) && (!v.duration || v.duration <= 180) && (!v.size || v.size <= MAX_BYTES))
    .slice(0, want * 3);

  return pool(
    candidates,
    3,
    async (v: any) => {
      const raw: string = v.play || v.hdplay || v.wmplay;
      const url = raw.startsWith("http") ? raw : `https://www.tikwm.com${raw}`;
      const buffer = await withTimeout(downloadBuffer(url, () => {}, "tiktok"), PER_VIDEO_TIMEOUT, "TIKTOK_DL_TIMEOUT");
      if (!buffer?.length || buffer.length > MAX_BYTES) return null;
      return {
        title: clean(v.title) || normalized,
        author: clean(v.author) || "—",
        source: "TikTok" as const,
        buffer,
        url: v.video_id && v.author?.unique_id ? `https://www.tiktok.com/@${v.author.unique_id}/video/${v.video_id}` : undefined,
      };
    },
    want
  );
}

async function fromYouTube(query: string, want: number): Promise<EditVideo[]> {
  if (isYoutubeBlocked()) throw new Error("YOUTUBE_BLOCKED_SKIP");
  const variants = [`${query} edit shorts`, `${query} edit`, `${query} amv`, `${query} capcut edit`];
  const seen = new Set<string>();
  const out: EditVideo[] = [];
  for (const q of variants) {
    if (out.length >= want) break;
    let hits: Awaited<ReturnType<typeof ytdlpSearch>> = [];
    try {
      hits = await ytdlpSearch(q, 10);
    } catch (err) {
      logger.warn("⚠️ yt-dlp search فشل:", err instanceof Error ? err.message : err);
      try {
        const r = await withTimeout(ytSearch(q), 12_000, "YT_SEARCH_TIMEOUT");
        hits = (r?.videos || []).map((v: any) => ({ url: v.url, title: v.title, uploader: v.author?.name || "", duration: v.seconds || 0 }));
      } catch {
        continue;
      }
    }
    const candidates = hits.filter((h) => !seen.has(h.url) && h.duration > 0 && h.duration <= 120);
    candidates.forEach((c) => seen.add(c.url));
    const got = await pool(
      candidates.slice(0, (want - out.length) * 2),
      1,
      async (h) => {
        const { buffer } = await ytdlpDownload(h.url, "video", { maxHeight: 480, maxBytes: MAX_BYTES });
        if (!buffer?.length || buffer.length > MAX_BYTES) return null;
        return {
          title: clean(h.title) || query,
          author: clean(h.uploader) || "—",
          source: "YouTube" as const,
          buffer: await ensureWhatsAppMp4(buffer),
          url: h.url,
        };
      },
      want - out.length
    );
    out.push(...got);
  }
  return out;
}

/** اكتشاف روابط فيديوهات تيك توك/انستقرام/فيسبوك عبر Tavily (بحث ويب دلالي) ثم تحميلها بـyt-dlp */
async function fromWebDiscovered(query: string, want: number): Promise<EditVideo[]> {
  if (!CONFIG.TAVILY_API_KEY || want <= 0) return [];
  const res = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    signal: AbortSignal.timeout(15_000),
    body: JSON.stringify({
      api_key: CONFIG.TAVILY_API_KEY,
      query: `${query} edit`,
      search_depth: "basic",
      max_results: 15,
      include_domains: ["tiktok.com", "instagram.com", "facebook.com"],
    }),
  });
  if (!res.ok) throw new Error(`TAVILY_HTTP_${res.status}`);
  const json: any = await res.json();
  const isVideoUrl = (u: string) =>
    /tiktok\.com\/@[^/]+\/video\/\d+/i.test(u) || /instagram\.com\/(reel|reels|p)\/[\w-]+/i.test(u) || /facebook\.com\/.+\/(videos|reel)\//i.test(u);
  const hits = (json?.results || []).filter((r: any) => r?.url && isVideoUrl(r.url));
  return pool(
    hits.slice(0, want * 3),
    1,
    async (r: any) => {
      const { buffer } = await ytdlpDownload(r.url, "video", { maxHeight: 480, maxBytes: MAX_BYTES });
      if (!buffer?.length || buffer.length > MAX_BYTES) return null;
      const platform = /tiktok/i.test(r.url) ? "TikTok" : /instagram/i.test(r.url) ? "Instagram" : "Facebook";
      const handle = /tiktok\.com\/(@[^/]+)/i.exec(r.url)?.[1] || "";
      return {
        title: clean(r.title) || query,
        author: handle || "—",
        source: platform,
        buffer: await ensureWhatsAppMp4(buffer),
        url: r.url,
      };
    },
    want
  );
}

/** بيلي بيلي (ضخم بتصاميم الأنمي/AMV) عبر بحث yt-dlp المدمج */
async function fromBilibili(query: string, want: number): Promise<EditVideo[]> {
  if (want <= 0) return [];
  const hits = await ytdlpSearch(`${query} edit`, 10, "bilisearch");
  const candidates = hits.filter((h) => h.duration === 0 || h.duration <= 150).slice(0, want * 3);
  return pool(
    candidates,
    1,
    async (h) => {
      const { buffer } = await ytdlpDownload(h.url, "video", { maxHeight: 480, maxBytes: MAX_BYTES });
      if (!buffer?.length || buffer.length > MAX_BYTES) return null;
      return { title: clean(h.title) || query, author: clean(h.uploader) || "—", source: "Bilibili", buffer: await ensureWhatsAppMp4(buffer), url: h.url };
    },
    want
  );
}

/**
 * 🆕 مصدر احتياطي لا يحتاج كوكيز: واجهات Piped العامة (وسيط مفتوح ليوتيوب) — بحث + رابط تحميل مباشر.
 * القائمة قابلة للتعديل بـPIPED_INSTANCES بالـ.env (روابط API مفصولة بفاصلة). النسخ العامة تتعطل أحيانًا،
 * فنجرّبها بالترتيب ونتخطى أي واحدة ما ترد.
 */
const DEFAULT_PIPED = ["https://pipedapi.kavin.rocks", "https://api.piped.private.coffee", "https://pipedapi.adminforge.de", "https://pipedapi.leptons.xyz"];

async function pipedJson(url: string): Promise<any> {
  const res = await fetch(url, { signal: AbortSignal.timeout(12_000), headers: { "User-Agent": "Mozilla/5.0" } });
  if (!res.ok) throw new Error(`HTTP_${res.status}`);
  return res.json();
}

async function fromPiped(query: string, want: number): Promise<EditVideo[]> {
  if (want <= 0) return [];
  const instances = (process.env.PIPED_INSTANCES || "").split(",").map((x) => x.trim().replace(/\/$/, "")).filter(Boolean);
  for (const base of instances.length ? instances : DEFAULT_PIPED) {
    try {
      const search = await pipedJson(`${base}/search?q=${encodeURIComponent(`${query} edit`)}&filter=videos`);
      const items = (search?.items || []).filter((v: any) => v?.url && (!v.duration || (v.duration > 0 && v.duration <= 150))).slice(0, want * 3);
      if (!items.length) continue;
      const got = await pool(
        items,
        1,
        async (v: any) => {
          const id = String(v.url).replace(/^.*[?&]v=/, "");
          const info = await pipedJson(`${base}/streams/${encodeURIComponent(id)}`);
          const progressive = (info?.videoStreams || [])
            .filter((x: any) => x && x.videoOnly === false && /mp4/i.test(String(x.format || x.mimeType)) && x.url)
            .sort((a: any, b: any) => (parseInt(a.quality) || 999) - (parseInt(b.quality) || 999));
          const pick = progressive.find((x: any) => (parseInt(x.quality) || 0) >= 240) || progressive[0];
          if (!pick) return null;
          const buffer = await withTimeout(downloadBuffer(pick.url, () => {}, "direct"), PER_VIDEO_TIMEOUT, "PIPED_DL_TIMEOUT");
          if (!buffer?.length || buffer.length > MAX_BYTES) return null;
          return { title: clean(v.title) || query, author: clean(v.uploaderName) || "—", source: "YouTube", buffer: await ensureWhatsAppMp4(buffer), url: `https://www.youtube.com/watch?v=${id}` };
        },
        want
      );
      if (got.length) return got;
    } catch (err) {
      logger.warn(`⚠️ Piped ${base} فشل:`, err instanceof Error ? err.message : err);
    }
  }
  return [];
}

export async function searchEditVideos(query: string, want = 5): Promise<{ videos: EditVideo[]; errors: string[] }> {
  const errors: string[] = [];
  let videos: EditVideo[] = [];
  const tiers: Array<[string, () => Promise<EditVideo[]>, boolean]> = [
    ["tiktok", () => fromTikTok(query, want - videos.length), true],
    ["web(tiktok/instagram/facebook)", () => fromWebDiscovered(query, want - videos.length), false],
    ["youtube", () => fromYouTube(query, want - videos.length), false],
    ["piped", () => fromPiped(query, want - videos.length), false],
    ["bilibili", () => fromBilibili(query, want - videos.length), false],
  ];
  const deadline = Date.now() + 50_000; // ميزانية وقت: أقل من مهلة الأمر حتى ما يطلع COMMAND_TIMEOUT
  for (const [name, run, isTikwm] of tiers) {
    if (videos.length >= want || Date.now() > deadline) break;
    try {
      const more = await run();
      videos = videos.concat(more);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      errors.push(`${name}: ${msg}`);
      if (isTikwm && /TIKWM_UNREACHABLE|401|403|429/.test(msg)) tikwmDownUntil = Date.now() + 10 * 60_000;
    }
  }
  return { videos: videos.slice(0, want), errors };
}
