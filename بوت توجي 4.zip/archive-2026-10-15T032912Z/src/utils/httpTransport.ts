import http from "http";
import https from "https";
import { isIP } from "net";
import type { ClientRequest, IncomingMessage, RequestOptions } from "http";

interface HttpTransport {
  get(url: string, options: RequestOptions, callback: (response: IncomingMessage) => void): ClientRequest;
  request(options: RequestOptions, callback: (response: IncomingMessage) => void): ClientRequest;
}

function isPrivateIpv4(address: string): boolean {
  const parts = address.split(".").map(Number);
  if (parts.length !== 4 || parts.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) {
    return true;
  }
  const [a, b] = parts;
  return (
    a === 0 ||
    a === 10 ||
    a === 127 ||
    a >= 224 ||
    (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) ||
    (a === 100 && b >= 64 && b <= 127)
  );
}

function isPrivateAddress(hostname: string): boolean {
  const host = hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (
    host === "localhost" ||
    host.endsWith(".localhost") ||
    host.endsWith(".local") ||
    host.endsWith(".internal")
  ) {
    return true;
  }
  const version = isIP(host);
  if (version === 4) return isPrivateIpv4(host);
  if (version === 6) {
    if (host.startsWith("::ffff:")) return isPrivateIpv4(host.slice(7));
    return host === "::" || host === "::1" || /^f[cd]/i.test(host) || /^fe[89ab]/i.test(host);
  }
  return false;
}

/**
 * Selects HTTP or HTTPS for real image/CDN URLs and rejects local destinations.
 * Search and media results are external input, so they must not reach localhost
 * or private IP addresses.
 */
export function getHttpTransport(url: string): HttpTransport {
  const parsed = new URL(url);
  if (parsed.username || parsed.password || isPrivateAddress(parsed.hostname)) {
    throw new Error("UNSAFE_URL");
  }
  if (parsed.protocol === "https:") return https as unknown as HttpTransport;
  if (parsed.protocol === "http:") return http as unknown as HttpTransport;
  throw new Error("UNSUPPORTED_PROTOCOL");
}
