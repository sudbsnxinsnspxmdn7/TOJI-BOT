import { downloadImageBuffer } from "./imageSearch";
import { logger } from "./logger";

/**
 * يحمّل روابط صور (بتوازي محدود) ويرجع أول N buffers ناجحة بالترتيب.
 * مشترك بين .صور (كاروسيل) و.بحث (عنوان + كاروسيل صور).
 */
export async function downloadFirstImages(urls: string[], want = 5, batch = 4): Promise<Buffer[]> {
  const out: Buffer[] = [];
  for (let i = 0; i < urls.length && out.length < want; i += batch) {
    const slice = urls.slice(i, i + batch);
    const res = await Promise.allSettled(slice.map((u) => downloadImageBuffer(u)));
    for (const r of res) {
      if (r.status === "fulfilled" && r.value?.length > 2000 && out.length < want) out.push(r.value);
      else if (r.status === "rejected") logger.warn("⚠️ فشل تحميل صورة بحث:", r.reason instanceof Error ? r.reason.message : r.reason);
    }
  }
  return out;
}
