import { GoogleGenAI } from "@google/genai";
import { CONFIG } from "../config/config";
import { logger } from "./logger";

/**
 * توليد صورة: يجرّب Gemini أولًا (لو GEMINI_API_KEY موجود) بعدة أسماء موديلات، ولو فشل (حصة/موديل/مفتاح)
 * يرجع تلقائيًا لخدمة Pollinations المجانية (بدون مفتاح) — فيشتغل .رسم/.ارسم حتى لو Gemini تعطّل.
 * ⚠️ ما قدرت أجرّب أي خدمة من بيئتي (الشبكة مقيّدة)؛ لو فشلت الاثنتين الخطأ الفعلي يوصل المطور.
 */
const GEMINI_MODELS = ["gemini-2.5-flash-image", "gemini-2.0-flash-preview-image-generation"];

async function viaGemini(prompt: string): Promise<Buffer> {
  if (!CONFIG.GEMINI_API_KEY) throw new Error("NO_GEMINI_KEY");
  const ai = new GoogleGenAI({ apiKey: CONFIG.GEMINI_API_KEY });
  let lastErr: unknown;
  for (const model of GEMINI_MODELS) {
    try {
      const response: any = await ai.models.generateContent({
        model,
        contents: prompt,
        ...(model.includes("2.0") ? { config: { responseModalities: ["TEXT", "IMAGE"] } } : {}),
      });
      const parts = response.candidates?.[0]?.content?.parts ?? [];
      const img = parts.find((p: any) => p.inlineData?.data);
      if (img) return Buffer.from(img.inlineData.data, "base64");
      lastErr = new Error("NO_IMAGE_RETURNED");
    } catch (err) {
      lastErr = err;
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error("GEMINI_FAILED");
}

async function viaPollinations(prompt: string): Promise<Buffer> {
  const seed = Math.floor(Math.random() * 1_000_000);
  const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=768&height=768&nologo=true&seed=${seed}`;
  const res = await fetch(url, { signal: AbortSignal.timeout(70_000), headers: { "User-Agent": "Mozilla/5.0" } });
  if (!res.ok) throw new Error(`POLLINATIONS_HTTP_${res.status}`);
  const type = res.headers.get("content-type") || "";
  if (!type.startsWith("image/")) throw new Error("POLLINATIONS_NOT_IMAGE");
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length < 5000) throw new Error("POLLINATIONS_EMPTY");
  return buf;
}

export async function generateImage(prompt: string): Promise<Buffer> {
  try {
    return await viaGemini(prompt);
  } catch (geminiErr) {
    logger.warn("⚠️ Gemini للرسم فشل، نجرّب Pollinations:", geminiErr instanceof Error ? geminiErr.message : geminiErr);
    try {
      return await viaPollinations(prompt);
    } catch (pollErr) {
      const g = geminiErr instanceof Error ? geminiErr.message : String(geminiErr);
      const p = pollErr instanceof Error ? pollErr.message : String(pollErr);
      throw new Error(`gemini: ${g.slice(0, 120)} | pollinations: ${p}`);
    }
  }
}
