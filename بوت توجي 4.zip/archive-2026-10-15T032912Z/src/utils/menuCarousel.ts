import { WASocket, WAMessage } from "@whiskeysockets/baileys";
import { CONFIG } from "../config/config";
import { sendCarousel, CarouselCard, CarouselButton } from "./carousel";
import { sectionButton } from "./interactive";

/**
 * قوائم الأوامر ككاروسيل (بطاقات تتحرك يمين/يسار) — لقائمة .اوامر والأوامر
 * الجانبية والفعاليات وغيرها.
 *
 * وضعان:
 *  • "buttons": كل بطاقة فيها حتى 3 أقسام، كل قسم زر حقيقي يشغّل أمره
 *    (يسجَّل بخريطة matchButtonTrigger عبر sectionButton فيشتغل بالضغط).
 *  • "list": كل بطاقة تعرض قائمة نصية بأسماء الأوامر (للقوائم الطويلة،
 *    لأن واتساب يسمح بـ3 أزرار فقط لكل بطاقة و10 بطاقات كحد أقصى).
 */
export interface MenuItem {
  command: string;
  label: string;
  description?: string;
}

const MAX_CARDS = 10;

function stripDecor(label: string): string {
  return label.replace(/[『』〘〙]/g, "").trim();
}

export async function sendMenuCarousel(
  sock: WASocket,
  chatId: string,
  opts: {
    title: string;
    intro: string;
    items: MenuItem[];
    image: Buffer;
    mode: "buttons" | "list";
    quoted?: WAMessage;
    mentions?: string[];
  }
): Promise<void> {
  const short = CONFIG.BOT_NAME.replace(/\\n|\n/g, " ");
  const p = CONFIG.PREFIX;
  const items = opts.items.filter((it, i, arr) => arr.findIndex((x) => x.command === it.command) === i);

  const perCard = opts.mode === "buttons" ? 3 : Math.max(6, Math.ceil(items.length / MAX_CARDS));
  const chunks: MenuItem[][] = [];
  for (let i = 0; i < items.length; i += perCard) chunks.push(items.slice(i, i + perCard));
  const limited = chunks.slice(0, MAX_CARDS);

  const cards: CarouselCard[] = limited.map((chunk, idx) => {
    const header = `✦ ${opts.title} ✦  (${idx + 1}/${limited.length})\n`;
    if (opts.mode === "buttons") {
      const body =
        header +
        chunk.map((it) => `• ${stripDecor(it.label)}${it.description ? `\n   ${stripDecor(it.description)}` : ""}`).join("\n");
      const buttons: CarouselButton[] = chunk.map((it) => ({
        type: "reply",
        label: it.label.length > 24 ? it.label.slice(0, 23) + "…" : it.label,
        value: sectionButton(it.command, it.label.length > 24 ? it.label.slice(0, 23) + "…" : it.label).id,
      }));
      return { image: opts.image, body, footer: short, buttons };
    }
    const body =
      header +
      chunk.map((it) => `• ${p}${it.command}  ${stripDecor(it.label).replace(/^\S+\s*/, "")}`.trimEnd()).join("\n");
    return { image: opts.image, body, footer: short }; // بدون أزرار قوائم (زر القناة الافتراضي فقط)
  });

  await sendCarousel(sock, chatId, {
    text: `${opts.intro}\n➜ اسحب لرؤية باقي القوائم`,
    footer: short,
    cards,
    quoted: opts.quoted,
    mentions: opts.mentions,
    onFail: "throw",
  });
}
