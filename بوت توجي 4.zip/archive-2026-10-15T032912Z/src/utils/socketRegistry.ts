import { WASocket } from "@whiskeysockets/baileys";

/**
 * سجل مركزي بكل مقابس واتساب المتصلة حاليًا بهذي العملية (الرئيسي + كل البوتات
 * الفرعية) — يستخدمه .جروبات ليجمع كل مجموعات السيرفر كاملًا لا مجموعات رقم واحد.
 */
const sockets = new Map<string, WASocket>();

export function registerSocket(label: string, sock: WASocket): void {
  sockets.set(label, sock);
}

export function unregisterSocket(label: string, sock?: WASocket): void {
  // لا نحذف لو سجّل مقبس أحدث بنفس الاسم (إعادة اتصال)
  if (!sock || sockets.get(label) === sock) sockets.delete(label);
}

export function getAllSockets(): Array<{ label: string; sock: WASocket }> {
  return [...sockets.entries()].map(([label, sock]) => ({ label, sock }));
}
