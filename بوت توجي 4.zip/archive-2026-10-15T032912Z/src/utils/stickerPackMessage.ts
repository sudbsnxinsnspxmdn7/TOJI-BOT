import { WASocket, WAMessage, proto, generateWAMessageFromContent, generateMessageIDV2 } from "@whiskeysockets/baileys";
import { MEDIA_HKDF_KEY_MAPPING, MEDIA_PATH_MAP } from "@whiskeysockets/baileys/lib/Defaults/index.js";
import { encryptedStream, getMediaKeys } from "@whiskeysockets/baileys/lib/Utils/messages-media.js";
import fs from "fs";
import os from "os";
import path from "path";
import crypto from "crypto";
import sharp from "sharp";
import { buildZip } from "./zip";
import { logger } from "./logger";

/**
 * 📦 حزمة ملصقات واتساب الأصلية (رسالة stickerPackMessage) — نفس اللي بصورتك:
 * بطاقة بعنوان الحزمة + زر "عرض مجموعة الملصقات" يفتح الحزمة داخل واتساب نفسه.
 *
 * مكتبة Baileys المثبتة (6.7.24) فيها تعريف الرسالة بالـproto لكن ما فيها دالة بناء/رفع.
 * هذا الكود منقول بتصرف من تنفيذ حزمة ملصقات موجودة بفرع Baileys منشور (@kelvdra/baileys
 * lib/Utils/messages.js) ومتكيّف مع الدوال الداخلية المثبتة عندك:
 *   1) تحويل كل صورة لـWebP 512×512  2) ضغطها كلها بـZIP + أيقونة الغلاف
 *   3) تشفير ورفع الـZIP بنوع الوسائط "sticker-pack" + رفع صورة مصغّرة
 *   4) إرسال رسالة stickerPackMessage.
 *
 * ⚠️ صراحة: هذي رسالة غير موثّقة رسميًا من واتساب، ولم أستطع تجربتها على واتساب حقيقي من بيئتي.
 * لو فشلت أو ما ظهر الزر عندك، السبب الفعلي يرجع للخطأ ويوصل المطور.
 */
(MEDIA_HKDF_KEY_MAPPING as any)["sticker-pack"] = "Sticker Pack";
(MEDIA_HKDF_KEY_MAPPING as any)["thumbnail-sticker-pack"] = "Sticker Pack";
(MEDIA_PATH_MAP as any)["sticker-pack"] = "/mms/sticker";
(MEDIA_PATH_MAP as any)["thumbnail-sticker-pack"] = "/mms/sticker";

const sha256 = (b: Buffer) => crypto.createHash("sha256").update(b).digest();
const EMOJIS = ["😀", "😂", "😍", "🔥", "👍", "🎉", "😎", "🤩", "💯", "🥳"];

export interface PackOptions {
  name: string;
  publisher: string;
  description?: string;
  /** صور خام (أي صيغة) — تتحول لـWebP هنا */
  images: Buffer[];
  mentions?: string[];
  quoted?: WAMessage;
}

async function toSticker(img: Buffer): Promise<Buffer | null> {
  try {
    const webp = await sharp(img)
      .resize(512, 512, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
      .webp({ quality: 75, effort: 4 })
      .toBuffer();
    return webp.length <= 1024 * 1024 ? webp : null;
  } catch {
    return null;
  }
}

/** ينتظر انتهاء كتابة الملف المشفّر (encryptedStream يرجع قبل ما ينتهي flush أحيانًا) */
async function waitForFile(file: string): Promise<void> {
  let last = -1;
  for (let i = 0; i < 100; i++) {
    const size = fs.existsSync(file) ? fs.statSync(file).size : 0;
    if (size > 0 && size === last) return;
    last = size;
    await new Promise((r) => setTimeout(r, 50));
  }
}

async function upload(sock: WASocket, encFilePath: string, fileEncSha256: Buffer, mediaType: "sticker-pack" | "thumbnail-sticker-pack") {
  await waitForFile(encFilePath);
  return (sock as any).waUploadToServer(encFilePath, {
    fileEncSha256B64: fileEncSha256.toString("base64"),
    mediaType,
    timeoutMs: mediaType === "sticker-pack" ? 300000 : 60000,
  });
}

async function uploadPack(sock: WASocket, data: Buffer) {
  const enc: any = await (encryptedStream as any)(data, "sticker-pack" as any, { opts: {} });
  const up: any = await upload(sock, enc.encFilePath, enc.fileEncSha256, "sticker-pack");
  return { enc, up };
}

/**
 * تشفير الصورة المصغّرة بنفس mediaKey الخاص بالحزمة (رسالة واحدة = مفتاح واحد).
 * encryptedStream بالنسخة المثبتة يولّد مفتاحًا عشوائيًا جديدًا دائمًا، فنشفّرها يدويًا
 * بنفس خوارزمية واتساب: AES-256-CBC + أول 10 بايت من HMAC-SHA256.
 */
async function uploadThumbnailWithKey(sock: WASocket, data: Buffer, mediaKey: Buffer) {
  const { cipherKey, iv, macKey } = await (getMediaKeys as any)(mediaKey, "thumbnail-sticker-pack");
  const cipher = crypto.createCipheriv("aes-256-cbc", cipherKey, iv);
  const body = Buffer.concat([cipher.update(data), cipher.final()]);
  const mac = crypto.createHmac("sha256", macKey).update(iv).update(body).digest().subarray(0, 10);
  const encrypted = Buffer.concat([body, mac]);
  const file = path.join(os.tmpdir(), `thumb-${crypto.randomUUID()}-enc`);
  fs.writeFileSync(file, encrypted);
  try {
    const fileEncSha256 = sha256(encrypted);
    const up: any = await upload(sock, file, fileEncSha256, "thumbnail-sticker-pack");
    return { fileSha256: sha256(data), fileEncSha256, directPath: up.directPath };
  } finally {
    fs.rmSync(file, { force: true });
  }
}

/** يبني الحزمة ويرسلها. يرجع عدد الملصقات الفعلي بالحزمة. */
export async function sendStickerPack(sock: WASocket, chatId: string, opts: PackOptions): Promise<number> {
  const converted = (await Promise.all(opts.images.map(toSticker))).filter((b): b is Buffer => !!b);
  if (!converted.length) throw new Error("NO_STICKER_CONVERTED");

  const packId = generateMessageIDV2();
  const files: { name: string; data: Buffer }[] = [];
  const meta: any[] = [];
  const seen = new Set<string>();
  converted.forEach((webp, i) => {
    const fileName = `${sha256(webp).toString("base64").replace(/\//g, "-").replace(/=/g, "")}.webp`;
    if (seen.has(fileName)) return;
    seen.add(fileName);
    files.push({ name: fileName, data: webp });
    meta.push({ fileName, mimetype: "image/webp", isAnimated: false, isLottie: false, emojis: [EMOJIS[i % EMOJIS.length]], accessibilityLabel: "" });
  });

  const trayName = `${packId}.webp`;
  files.push({ name: trayName, data: converted[0] });
  const zip = buildZip(files);
  if (zip.length > 10 * 1024 * 1024) throw new Error(`PACK_TOO_LARGE_${(zip.length / 1048576).toFixed(1)}MB`);

  const { enc, up } = await uploadPack(sock, zip);

  const message: any = {
    name: opts.name,
    publisher: opts.publisher,
    stickerPackId: packId,
    packDescription: opts.description || "",
    stickerPackOrigin: proto.Message.StickerPackMessage.StickerPackOrigin.THIRD_PARTY,
    stickerPackSize: zip.length,
    stickers: meta,
    fileSha256: enc.fileSha256,
    fileEncSha256: enc.fileEncSha256,
    mediaKey: enc.mediaKey,
    directPath: up.directPath,
    fileLength: enc.fileLength,
    mediaKeyTimestamp: Math.floor(Date.now() / 1000),
    trayIconFileName: trayName,
  };

  try {
    const thumb = await sharp(converted[0]).resize(252, 252, { fit: "cover" }).jpeg({ quality: 80 }).toBuffer();
    const t = await uploadThumbnailWithKey(sock, thumb, enc.mediaKey);
    Object.assign(message, {
      thumbnailDirectPath: t.directPath,
      thumbnailSha256: t.fileSha256,
      thumbnailEncSha256: t.fileEncSha256,
      thumbnailHeight: 252,
      thumbnailWidth: 252,
      imageDataHash: sha256(thumb).toString("base64"),
    });
  } catch (err) {
    logger.warn("⚠️ تعذر رفع صورة مصغّرة للحزمة (تكمل بدونها):", err instanceof Error ? err.message : err);
  }

  if (opts.mentions?.length) message.contextInfo = { mentionedJid: opts.mentions };

  const content = proto.Message.fromObject({ stickerPackMessage: message });
  const waMessage = generateWAMessageFromContent(chatId, content, {
    userJid: sock.user?.id || "",
    quoted: opts.quoted?.message ? opts.quoted : undefined,
  } as any);
  await sock.relayMessage(chatId, waMessage.message!, { messageId: waMessage.key.id || undefined });
  return meta.length;
}
