import { execFile } from "child_process";
import fs from "fs";
import os from "os";
import path from "path";
import { logger } from "./logger";
import { getCookies } from "./cookies";

/**
 * 🆕 yt-dlp كاحتياطي شامل لكل أوامر التحميل.
 * يدعم يوتيوب/تيك توك/انستقرام/فيسبوك/تويتر(X)/ريديت/ساوندكلاود وأكثر من 1000 موقع،
 * ويُحدَّث من مشروعه بشكل مستمر (الحل الأكثر صمودًا قدام تغيّر المواقع).
 *
 * الملف التنفيذي يُنزَّل تلقائيًا مرة واحدة من github.com/yt-dlp/yt-dlp إلى ./bin
 * عند أول استخدام (لا يحتاج Python ولا تثبيت يدوي). لو استضافتك تمنع الوصول
 * لـ github أو تمنع تشغيل ملفات تنفيذية، ضع ملف yt-dlp بنفسك وحدّد مساره بـ YTDLP_PATH.
 * (اختياري) YTDLP_COOKIES_FILE = مسار ملف كوكيز Netscape لتجاوز "Sign in to confirm you're not a bot".
 */
const BIN_DIR = path.join(process.cwd(), "bin");
const MAX_BYTES = 64 * 1024 * 1024;
const RUN_TIMEOUT_MS = 150_000;

function assetName(): string {
  if (process.platform === "win32") return "yt-dlp.exe";
  if (process.platform === "darwin") return "yt-dlp_macos";
  return process.arch === "arm64" ? "yt-dlp_linux_aarch64" : "yt-dlp_linux";
}

let ensuring: Promise<string> | null = null;

async function ensureBinary(): Promise<string> {
  if (process.env.YTDLP_PATH) return process.env.YTDLP_PATH;
  const target = path.join(BIN_DIR, assetName());
  if (fs.existsSync(target) && fs.statSync(target).size > 1_000_000) return target;
  if (!ensuring) {
    ensuring = (async () => {
      fs.mkdirSync(BIN_DIR, { recursive: true });
      const url = `https://github.com/yt-dlp/yt-dlp/releases/latest/download/${assetName()}`;
      logger.info("⬇️ تنزيل yt-dlp (مرة واحدة)...");
      const res = await fetch(url, { redirect: "follow" });
      if (!res.ok) throw new Error(`YTDLP_DOWNLOAD_HTTP_${res.status}`);
      const buf = Buffer.from(await res.arrayBuffer());
      const tmp = `${target}.part`;
      fs.writeFileSync(tmp, buf);
      fs.chmodSync(tmp, 0o755);
      fs.renameSync(tmp, target);
      logger.success("✅ yt-dlp جاهز.");
      return target;
    })().finally(() => {
      ensuring = null;
    });
  }
  return ensuring;
}

/**
 * ⚠️ الاستضافة عندك ~308MB رام: ملف yt-dlp الجاهز ثقيل (عشرات الميجات عند التشغيل)، فنشغّل عملية
 * وحدة فقط كل مرة بدل ما نشغّل عدة عمليات بالتوازي ونتجاوز حد الذاكرة (سبب البطء/الانهيار).
 */
let queue: Promise<unknown> = Promise.resolve();
function run(bin: string, args: string[]): Promise<string> {
  const task = queue.then(() => runNow(bin, args), () => runNow(bin, args));
  queue = task.catch(() => undefined);
  return task;
}

export class YoutubeBotCheckError extends Error {}
let youtubeBlockedUntil = 0;
export function isYoutubeBlocked(): boolean {
  return Date.now() < youtubeBlockedUntil;
}

function runNow(bin: string, args: string[]): Promise<string> {
  return new Promise((resolve, reject) => {
    execFile(bin, args, { timeout: RUN_TIMEOUT_MS, maxBuffer: 10 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) {
        const full = String(stderr || err.message);
        const msg = full.split("\n").filter(Boolean).slice(-2).join(" ").slice(0, 300);
        // يوتيوب يحجب السيرفر ("Sign in to confirm you're not a bot") — نوقف المحاولات 20 دقيقة (بدل ما نكرّرها لكل فيديو)
        if (/confirm you.?re not a bot|Sign in to confirm/i.test(full)) {
          youtubeBlockedUntil = Date.now() + 20 * 60_000;
          return reject(new YoutubeBotCheckError("YOUTUBE_BOT_CHECK (يوتيوب يطلب كوكيز — راجع YTDLP_COOKIES_FILE بالـ.env)"));
        }
        return reject(new Error(msg || "YTDLP_FAILED"));
      }
      resolve(stdout);
    });
  });
}

export interface YtdlpResult {
  buffer: Buffer;
  ext: string;
  title: string;
}

export async function ytdlpDownload(
  url: string,
  kind: "video" | "audio" = "video",
  opts: { maxHeight?: number; maxBytes?: number } = {}
): Promise<YtdlpResult> {
  if (!/^https?:\/\//i.test(url)) throw new Error("BAD_URL");
  if (/youtu\.?be/i.test(url) && isYoutubeBlocked()) throw new YoutubeBotCheckError("YOUTUBE_BOT_CHECK (محجوب مؤقتًا)");
  const bin = await ensureBinary();
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "ytdlp-"));
  try {
    const common = [
      "--no-playlist", "--no-warnings", "--no-progress", "--max-filesize", `${opts.maxBytes ?? MAX_BYTES}`,
      "--socket-timeout", "20", "--retries", "2",
      "--print", "after_move:%(title)s",
      "-o", path.join(dir, "out.%(ext)s"),
    ];
    const ck = getCookies().file;
    if (ck) common.push("--cookies", ck);
    const fmt =
      kind === "audio"
        ? ["-f", "bestaudio[ext=m4a]/bestaudio"]
        : (() => {
            const h = opts.maxHeight ?? 720;
            // نفضّل H.264/AAC بملف واحد (يشتغل بواتساب بدون إعادة ترميز ولا دمج)
            return ["-f", `18/best[vcodec^=avc1][ext=mp4][height<=${h}]/best[vcodec^=avc1][height<=${h}]/best[ext=mp4][height<=${h}]/best[height<=${h}]/best`];
          })();
    const stdout = await run(bin, [...common, ...fmt, "--", url]);
    const file = fs.readdirSync(dir).find((f) => f.startsWith("out."));
    if (!file) throw new Error("NOT_FOUND");
    const full = path.join(dir, file);
    return { buffer: fs.readFileSync(full), ext: path.extname(file).slice(1), title: stdout.trim().split("\n").pop() || "" };
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
}

export interface YtdlpSearchHit {
  url: string;
  title: string;
  uploader: string;
  duration: number;
}

/** بحث يوتيوب عبر yt-dlp نفسه (أثبت من scraping مكتبة yt-search) */
export async function ytdlpSearch(query: string, count = 10, prefix = "ytsearch"): Promise<YtdlpSearchHit[]> {
  const bin = await ensureBinary();
  const args = ["--flat-playlist", "--dump-json", "--no-warnings", "--socket-timeout", "15", `${prefix}${count}:${query}`];
  const ck = getCookies().file;
  if (ck) args.unshift("--cookies", ck);
  const out = await run(bin, args);
  const hits: YtdlpSearchHit[] = [];
  for (const line of out.split("\n")) {
    if (!line.trim().startsWith("{")) continue;
    try {
      const j = JSON.parse(line);
      const url = j.webpage_url || (j.id ? `https://www.youtube.com/watch?v=${j.id}` : "");
      if (!url) continue;
      hits.push({ url, title: String(j.title || ""), uploader: String(j.uploader || j.channel || ""), duration: Number(j.duration || 0) });
    } catch {
      /* سطر غير JSON */
    }
  }
  return hits;
}
