const test = require("node:test");
const assert = require("node:assert/strict");
const { buildCommandDirectory, COMMANDS_PER_PAGE } = require("../dist/utils/commandDirectory");

const commands = Array.from({ length: 45 }, (_, index) => ({
  name: `أمر_${String(index + 1).padStart(2, "0")}`,
  description: `وصف الأمر ${index + 1}`,
  category: index < 24 ? "بوت" : "ادوات",
  permission: index === 0 ? "owner" : "all",
}));

test("command directory includes all commands across bounded pages", () => {
  const pages = Array.from({ length: 3 }, (_, index) =>
    buildCommandDirectory(commands, ".", index + 1)
  );
  assert.equal(pages[0].totalCommands, 45);
  assert.equal(pages[0].totalPages, 3);
  assert.equal(pages[0].page, 1);
  assert.equal(pages[1].page, 2);
  assert.equal(pages[2].page, 3);
  assert.equal(pages[0].text.split("\n").filter((line) => line.startsWith(".أمر_")).length, COMMANDS_PER_PAGE);
  assert.equal(pages[2].text.split("\n").filter((line) => line.startsWith(".أمر_")).length, 5);
  const listed = pages.flatMap((page) =>
    page.text.split("\n").filter((line) => /^\.أمر_\d+/.test(line))
  );
  assert.equal(new Set(listed).size, 45);
  assert.match(pages.map((page) => page.text).join("\n"), /وصف الأمر 1 \(للمطور فقط\)/);
  assert.match(pages[0].text, /للتنقل: \.اوامر_البوتس 2/);
});

test("invalid pages safely fall back to page one and aliases remain beside commands", () => {
  const page = buildCommandDirectory(
    [{ ...commands[0], aliases: ["اختصار"] }],
    "!",
    0
  );
  assert.equal(page.page, 1);
  assert.match(page.text, /!أمر_01 \(بدائل: !اختصار\)/);
});
