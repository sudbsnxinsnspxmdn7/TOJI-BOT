const test = require("node:test");
const assert = require("node:assert/strict");
const Module = require("node:module");

const originalLoad = Module._load;
Module._load = function (request, parent, isMain) {
  if (request === "../utils/logger" && parent?.filename.endsWith("/dist/handlers/commandRegistry.js")) {
    return { logger: { error() {}, warn() {}, success() {} } };
  }
  return originalLoad.call(this, request, parent, isMain);
};
const { commandRegistry } = require("../dist/handlers/commandRegistry");
Module._load = originalLoad;

const stubCommand = (name, aliases = []) => ({
  name,
  aliases,
  category: "بوت",
  description: name,
  permission: "all",
  execute: async () => {},
});

test("canonical command names win alias collisions and duplicate names do not overwrite", () => {
  commandRegistry.clear();
  const original = stubCommand("first", ["taken"]);
  const canonical = stubCommand("taken");
  commandRegistry.register(original);
  commandRegistry.register(canonical);
  commandRegistry.register(stubCommand("taken"));

  assert.equal(commandRegistry.get("taken"), canonical);
  assert.equal(commandRegistry.get("first"), original);
  assert.deepEqual(commandRegistry.getAliases("first"), []);
  assert.equal(commandRegistry.count(), 2);
});

test("the first alias owner remains stable and aliases are exposed for help", () => {
  commandRegistry.clear();
  const first = stubCommand("first", ["shared"]);
  commandRegistry.register(first);
  commandRegistry.register(stubCommand("second", ["shared"]));

  assert.equal(commandRegistry.get("shared"), first);
  assert.deepEqual(commandRegistry.getAliases("first"), ["shared"]);
  assert.equal(commandRegistry.getAliases("missing").length, 0);
});
