const test = require("node:test");
const assert = require("node:assert/strict");
const Module = require("node:module");

const replies = [];
const messages = [];
let resolveGenerateContent;
let markGenerateStarted;
const generateStarted = new Promise((resolve) => {
  markGenerateStarted = resolve;
});

class MockGoogleGenAI {
  constructor() {
    this.models = {
      generateContent: () =>
        new Promise((resolve) => {
          resolveGenerateContent = resolve;
          markGenerateStarted();
        }),
    };
  }
}

const originalLoad = Module._load;
Module._load = function (request, parent, isMain) {
  if (parent?.filename.endsWith("/dist/utils/genieGame.js")) {
    if (request === "@google/genai") return { GoogleGenAI: MockGoogleGenAI };
    if (request === "../config/config") return { CONFIG: { GEMINI_API_KEY: "test-key" } };
    if (request === "./interactive") {
      return {
        sendButtonMessage: async (_sock, _chatId, message) => messages.push(message),
        sectionButton: (id, title) => ({ id, title }),
      };
    }
    if (request === "./logger") return { logger: { error() {} } };
    if (request === "./friendUtils") {
      return {
        reply: async (_ctx, message) => {
          replies.push(message);
        },
      };
    }
    if (request === "./characterImage") return { getCharacterImage: async () => null };
  }
  return originalLoad.call(this, request, parent, isMain);
};
const { genieAnswer, genieStart } = require("../dist/utils/genieGame");
Module._load = originalLoad;

test("a second Akinator action cannot mutate a game while its AI reply is pending", async () => {
  replies.length = 0;
  messages.length = 0;

  const ctx = {
    chatId: "group@example.test",
    senderJid: "player@example.test",
    args: [],
    msg: {},
    sock: {},
  };

  const start = genieStart(ctx);
  await generateStarted;
  await genieAnswer(ctx, "مارد_نعم");
  resolveGenerateContent({ text: JSON.stringify({ type: "question", text: "هل الشخصية خيالية؟" }) });
  await start;

  assert.ok(replies.some((message) => message.includes("يعالج إجابة سابقة")));
  assert.equal(messages.length, 1);
  assert.match(messages[0].text, /هل الشخصية خيالية/);
});
