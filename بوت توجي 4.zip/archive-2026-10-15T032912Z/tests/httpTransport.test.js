const test = require("node:test");
const assert = require("node:assert/strict");
const http = require("node:http");
const https = require("node:https");
const { getHttpTransport } = require("../dist/utils/httpTransport");

test("selects the transport that matches the URL protocol", () => {
  assert.equal(getHttpTransport("http://example.com/image.jpg"), http);
  assert.equal(getHttpTransport("https://example.com/image.jpg"), https);
});

test("rejects unsupported, credentialed, and private-network URLs", () => {
  for (const url of [
    "ftp://example.com/file",
    "http://localhost/image.jpg",
    "http://127.0.0.1/image.jpg",
    "http://10.1.2.3/image.jpg",
    "http://192.168.1.10/image.jpg",
    "http://[::1]/image.jpg",
    "https://user:pass@example.com/image.jpg",
  ]) {
    assert.throws(() => getHttpTransport(url), /UNSAFE_URL|UNSUPPORTED_PROTOCOL/);
  }
});
